/*
 * This file is part of OpenTV.
 * Copyright (C) 2026 The OpenTV Contributors
 * Licensed under the GNU General Public License v3.0 or later.
 */
package app.opentv.youtube

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.schabi.newpipe.extractor.NewPipe
import org.schabi.newpipe.extractor.ServiceList
import org.schabi.newpipe.extractor.downloader.Downloader
import org.schabi.newpipe.extractor.downloader.Response
import org.schabi.newpipe.extractor.stream.StreamInfo

/** Resolves a stable official `/@channel/live` route to its current expiring HLS manifest. */
object YouTubeLiveResolver {
    private val initMutex = Mutex()
    @Volatile private var initialized = false

    suspend fun resolve(channelLiveUrl: String, client: OkHttpClient): String = withContext(Dispatchers.IO) {
        val html = client.newCall(
            Request.Builder()
                .url(channelLiveUrl)
                .header("User-Agent", USER_AGENT)
                .build(),
        ).execute().use { response ->
            check(response.isSuccessful) { "YouTube channel returned HTTP ${response.code}" }
            response.body?.string().orEmpty()
        }
        val videoId = LIVE_VIDEO.find(html)?.groupValues?.get(1)
            ?: error("This channel is not live right now")
        ensureInitialized(client)
        val info = StreamInfo.getInfo(ServiceList.YouTube, "https://www.youtube.com/watch?v=$videoId")
        info.hlsUrl.takeIf { it.isNotBlank() }
            ?: error("YouTube did not provide a playable live HLS stream")
    }

    private suspend fun ensureInitialized(client: OkHttpClient) {
        if (initialized) return
        initMutex.withLock {
            if (!initialized) {
                NewPipe.init(OkHttpDownloader(client))
                initialized = true
            }
        }
    }

    private class OkHttpDownloader(private val client: OkHttpClient) : Downloader() {
        override fun execute(request: org.schabi.newpipe.extractor.downloader.Request): Response {
            val body = request.dataToSend()?.toRequestBody()
            val builder = Request.Builder()
                .url(request.url())
                .method(request.httpMethod(), body)
                .header("User-Agent", USER_AGENT)
            request.headers().forEach { (name, values) ->
                builder.removeHeader(name)
                values.forEach { builder.addHeader(name, it) }
            }
            client.newCall(builder.build()).execute().use { response ->
                return Response(
                    response.code,
                    response.message,
                    response.headers.toMultimap(),
                    response.body?.string(),
                    response.request.url.toString(),
                )
            }
        }
    }

    // The /live page's player response puts this flag immediately before externalVideoId.
    private val LIVE_VIDEO = Regex("\\\"isLiveNow\\\":true.{0,1200}?\\\"externalVideoId\\\":\\\"([A-Za-z0-9_-]{11})\\\"")
    private const val USER_AGENT =
        "Mozilla/5.0 (Linux; Android 14; TV) AppleWebKit/537.36 Chrome/131.0 Safari/537.36"
}
