package app.opentv

import android.app.Application
import app.opentv.data.remote.StremioClient
import com.google.common.truth.Truth.assertThat
import kotlinx.serialization.json.Json
import okhttp3.mockwebserver.Dispatcher
import okhttp3.mockwebserver.MockResponse
import okhttp3.mockwebserver.MockWebServer
import okhttp3.mockwebserver.RecordedRequest
import okhttp3.OkHttpClient
import org.junit.After
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(application = Application::class)
class StremioClientTest {
    private lateinit var server: MockWebServer
    private lateinit var manifestUrl: String

    @Before
    fun setUp() {
        server = MockWebServer()
        server.dispatcher = object : Dispatcher() {
            override fun dispatch(request: RecordedRequest): MockResponse {
                val path = request.path.orEmpty()
                val body = when {
                path.endsWith("/manifest.json") -> """
                    {"id":"org.example.public-domain","name":"Public Domain Test","version":"1.2.3",
                     "resources":["catalog","stream"],"types":["movie"],
                     "catalogs":[{"type":"movie","id":"public","name":"Public Domain","extra":[{"name":"search"}]}],
                     "behaviorHints":{"p2p":true,"configurable":true}}
                """.trimIndent()
                path.contains("/catalog/movie/public/") -> """
                    {"metas":[{"id":"tt1254207","type":"movie","name":"Big Buck Bunny"}]}
                """.trimIndent()
                path.endsWith("/stream/movie/tt1254207.json") -> """
                    {"streams":[{"name":"Official trailer","ytId":"aqz-KE-bpKQ"},
                    {"name":"Authorised torrent","infoHash":"0123456789abcdef0123456789abcdef01234567",
                     "fileIdx":2,"sources":["tracker:https://tracker.example/announce"],
                     "behaviorHints":{"proxyHeaders":{"request":{"Referer":"https://media.example/","User-Agent":"Test Player"}}}}]}
                """.trimIndent()
                else -> "{}"
                }
                return MockResponse().setHeader("Content-Type", "application/json").setBody(body)
            }
        }
        server.start()
        manifestUrl = server.url("/manifest.json").toString()
    }

    @After
    fun tearDown() = server.shutdown()

    @Test
    fun parsesCapabilitiesAndSearchExtra() {
        val client = StremioClient(OkHttpClient(), Json { ignoreUnknownKeys = true })
        val manifest = client.manifest(manifestUrl)!!

        assertThat(manifest.version).isEqualTo("1.2.3")
        assertThat(manifest.p2p).isTrue()
        assertThat(manifest.configurable).isTrue()
        assertThat(manifest.catalogs.single().extras).contains("search")
        assertThat(client.search(manifestUrl, "Big Buck Bunny").single().second.name)
            .isEqualTo("Big Buck Bunny")
    }

    @Test
    fun convertsInfoHashAndFileIndexToExplicitMagnetHandoff() {
        val client = StremioClient(OkHttpClient(), Json { ignoreUnknownKeys = true })
        val stream = client.streams(manifestUrl, "Public Domain Test", "movie", "tt1254207").last()

        assertThat(stream.p2p).isTrue()
        assertThat(stream.external).isTrue()
        assertThat(stream.url).startsWith("magnet:?xt=urn:btih:0123456789abcdef0123456789abcdef01234567")
        assertThat(stream.url).contains("&so=2")
        assertThat(stream.url).contains("tracker.example")
        assertThat(stream.requestHeaders["Referer"]).isEqualTo("https://media.example/")
        assertThat(stream.requestHeaders["User-Agent"]).isEqualTo("Test Player")
    }

    @Test
    fun keepsYouTubeIdsInsideTheOpenTvPlayer() {
        val client = StremioClient(OkHttpClient(), Json { ignoreUnknownKeys = true })
        val stream = client.streams(manifestUrl, "Public Domain Test", "movie", "tt1254207").first()

        assertThat(stream.url).isEqualTo("https://www.youtube.com/watch?v=aqz-KE-bpKQ")
        assertThat(stream.external).isFalse()
        assertThat(stream.p2p).isFalse()
    }
}
