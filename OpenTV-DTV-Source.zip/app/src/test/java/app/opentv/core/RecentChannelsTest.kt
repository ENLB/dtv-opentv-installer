package app.opentv.core

import com.google.common.truth.Truth.assertThat
import org.junit.Test

class RecentChannelsTest {
    @Test fun `rewatching moves channel to front without duplicates`() {
        assertThat(RecentChannels.moveToFront(listOf("a", "b", "c"), "b"))
            .containsExactly("b", "a", "c").inOrder()
    }

    @Test fun `history retains only newest one hundred distinct channels`() {
        val updated = RecentChannels.moveToFront((1..100).map { "channel-$it" }, "new-channel")
        assertThat(updated).hasSize(100)
        assertThat(updated.first()).isEqualTo("new-channel")
        assertThat(updated.last()).isEqualTo("channel-99")
        assertThat(updated).doesNotContain("channel-100")
    }
}
