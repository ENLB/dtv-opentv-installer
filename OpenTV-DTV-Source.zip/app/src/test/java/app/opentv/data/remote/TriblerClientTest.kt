package app.opentv.data.remote

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class TriblerClientTest {
    @Test fun rawInfohashBecomesMagnet() {
        val hash = "0123456789abcdef0123456789abcdef01234567"
        assertEquals("magnet:?xt=urn:btih:$hash", TriblerClient.normalizeMagnet(hash))
    }

    @Test fun magnetInfohashIsExtracted() {
        val hash = "0123456789abcdef0123456789abcdef01234567"
        assertEquals(hash, TriblerClient.infohash("magnet:?xt=urn:btih:$hash&dn=Example&so=4"))
        assertNull(TriblerClient.infohash("https://example.test/video.mp4"))
    }
}
