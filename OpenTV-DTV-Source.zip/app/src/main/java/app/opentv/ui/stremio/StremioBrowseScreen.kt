/*
 * This file is part of OpenTV.
 * Copyright (C) 2026 The OpenTV Contributors
 * Licensed under the GNU General Public License v3.0 or later.
 */
package app.opentv.ui.stremio

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import app.opentv.core.ServiceLocator
import app.opentv.data.model.StremioAddon
import app.opentv.data.model.StremioCatalog
import app.opentv.data.model.StremioMeta
import app.opentv.data.model.StremioPlaybackRequest
import app.opentv.data.model.StremioStream
import app.opentv.data.model.StremioSubtitle
import app.opentv.data.model.StremioVideo
import coil.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * A provider-independent Stremio home screen. Catalogues come directly from installed manifests,
 * so an Xtream/Stalker VOD library and a TMDB key are not prerequisites.
 */
@Composable
fun StremioBrowseScreen(
    onOpenAddons: () -> Unit,
    onPlay: (StremioPlaybackRequest) -> Unit,
) {
    val context = LocalContext.current
    val graph = remember(context) { ServiceLocator.get(context) }
    val addons by graph.settings.stremioAddons.collectAsState()
    var rows by remember { mutableStateOf<List<Pair<StremioCatalog, List<StremioMeta>>>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var selected by remember { mutableStateOf<Pair<StremioCatalog, StremioMeta>?>(null) }

    LaunchedEffect(addons) {
        if (addons.isEmpty()) {
            rows = emptyList()
            return@LaunchedEffect
        }
        loading = true
        error = null
        rows = emptyList()
        coroutineScope {
            addons.forEach { addon ->
                launch {
                    val loaded = withContext(Dispatchers.IO) {
                        runCatching {
                            val catalogs = graph.stremioClient.manifest(addon.manifestUrl)?.catalogs.orEmpty()
                                .filter { it.type == "movie" || it.type == "series" || it.type == "tv" }
                                .take(MAX_CATALOG_ROWS)
                            coroutineScope {
                                catalogs.map { catalog ->
                                    async { catalog to graph.stremioClient.catalog(catalog).take(MAX_ITEMS_PER_ROW) }
                                }.awaitAll().filter { it.second.isNotEmpty() }
                            }
                        }
                    }
                    loaded.onSuccess { result ->
                        rows = (rows + result).distinctBy { "${it.first.manifestUrl}:${it.first.type}:${it.first.id}" }
                    }.onFailure { error = it.message ?: "Catalogue request failed" }
                }
            }
        }
        loading = false
    }

    selected?.let { (catalog, meta) ->
        StremioDetail(
            catalog = catalog,
            preview = meta,
            addons = addons,
            onBack = { selected = null },
            onPlay = onPlay,
        )
        return
    }

    Column(Modifier.fillMaxSize().padding(horizontal = 28.dp, vertical = 20.dp)) {
        Text("Stremio", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text(
            "Standalone catalogues from your installed add-ons",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Spacer(Modifier.height(18.dp))

        when {
            addons.isEmpty() -> EmptyState(
                title = "No Stremio add-ons installed",
                body = "Add a manifest that provides catalogues, metadata, direct streams or subtitles.",
                button = "Manage add-ons",
                onClick = onOpenAddons,
            )
            loading && rows.isEmpty() -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
            rows.isEmpty() -> EmptyState(
                title = "No catalogue rows found",
                body = error ?: "The installed manifests do not advertise movie, series or live-TV catalogues.",
                button = "Manage add-ons",
                onClick = onOpenAddons,
            )
            else -> LazyColumn(verticalArrangement = Arrangement.spacedBy(22.dp)) {
                items(rows, key = { "${it.first.manifestUrl}:${it.first.type}:${it.first.id}" }) { (catalog, metas) ->
                    Column {
                        Text(
                            "${catalog.name}  ·  ${catalog.addonName}",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold,
                        )
                        Spacer(Modifier.height(9.dp))
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            items(metas, key = { "${catalog.manifestUrl}:${it.type}:${it.id}" }) { meta ->
                                MetaCard(meta) { selected = catalog to meta }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun StremioDetail(
    catalog: StremioCatalog,
    preview: StremioMeta,
    addons: List<StremioAddon>,
    onBack: () -> Unit,
    onPlay: (StremioPlaybackRequest) -> Unit,
) {
    val context = LocalContext.current
    val graph = remember(context) { ServiceLocator.get(context) }
    var meta by remember(preview.id) { mutableStateOf(preview) }
    var selectedVideo by remember(preview.id) { mutableStateOf<StremioVideo?>(null) }
    var streams by remember(preview.id) { mutableStateOf<List<StremioStream>>(emptyList()) }
    var subtitles by remember(preview.id) { mutableStateOf<List<StremioSubtitle>>(emptyList()) }
    var loadingMeta by remember(preview.id) { mutableStateOf(true) }
    var loadingSources by remember(preview.id) {
        mutableStateOf(preview.type == "movie" || preview.type == "tv")
    }

    BackHandler(onBack = onBack)

    suspend fun loadSources(id: String) {
        loadingSources = true
        val result = withContext(Dispatchers.IO) {
            coroutineScope {
                val capable = addons.map { addon ->
                    async { addon to graph.stremioClient.manifest(addon.manifestUrl) }
                }.awaitAll()
                val streamJobs = capable.filter { it.second?.resources?.contains("stream") == true }.map { (addon, _) ->
                    async { graph.stremioClient.streams(addon.manifestUrl, addon.name, preview.type, id) }
                }
                val subtitleJobs = capable.filter { it.second?.resources?.contains("subtitles") == true }.map { (addon, _) ->
                    async { graph.stremioClient.subtitles(addon.manifestUrl, preview.type, id) }
                }
                streamJobs.awaitAll().flatten().distinctBy { it.url } to
                    subtitleJobs.awaitAll().flatten().distinctBy { "${it.language}:${it.url}" }
            }
        }
        streams = result.first
        subtitles = result.second
        loadingSources = false
    }

    LaunchedEffect(preview.id, addons) {
        loadingMeta = true
        meta = withContext(Dispatchers.IO) {
            val ordered = listOf(catalog.manifestUrl) + addons.map { it.manifestUrl }
            ordered.distinct().firstNotNullOfOrNull { manifest ->
                graph.stremioClient.meta(manifest, preview.type, preview.id)
            } ?: preview
        }
        loadingMeta = false
        if (preview.type == "movie" || preview.type == "tv") loadSources(preview.id)
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(32.dp),
    ) {
        Row(horizontalArrangement = Arrangement.spacedBy(24.dp)) {
            AsyncImage(
                model = meta.poster,
                contentDescription = meta.name,
                contentScale = ContentScale.Crop,
                modifier = Modifier.width(190.dp).height(if (meta.type == "tv") 190.dp else 285.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant),
            )
            Column(Modifier.weight(1f)) {
                Text(meta.name, style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
                val facts = listOfNotNull(meta.releaseInfo, meta.imdbRating?.let { "IMDb $it" }) + meta.genres
                if (facts.isNotEmpty()) {
                    Spacer(Modifier.height(8.dp))
                    Text(facts.joinToString("  ·  "), color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                meta.description?.let {
                    Spacer(Modifier.height(14.dp))
                    Text(it, style = MaterialTheme.typography.bodyLarge, maxLines = 7, overflow = TextOverflow.Ellipsis)
                }
                if (loadingMeta) {
                    Spacer(Modifier.height(16.dp))
                    CircularProgressIndicator(Modifier.size(28.dp))
                }
            }
        }

        if (meta.type == "series") {
            Spacer(Modifier.height(28.dp))
            Text("Episodes", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(10.dp))
            if (!loadingMeta && meta.videos.isEmpty()) {
                Text("This metadata add-on did not return episode information.")
            } else {
                Row(
                    Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    meta.videos.sortedWith(compareBy({ it.season ?: 0 }, { it.episode ?: 0 })).forEach { video ->
                        val label = when {
                            video.season != null && video.episode != null -> "S${video.season} E${video.episode} · ${video.title}"
                            else -> video.title
                        }
                        FocusCard(
                            text = label,
                            selected = selectedVideo?.id == video.id,
                            modifier = Modifier.width(240.dp),
                        ) {
                            selectedVideo = video
                        }
                    }
                }
                LaunchedEffect(selectedVideo?.id) {
                    selectedVideo?.let { loadSources(it.id) }
                }
            }
        }

        Spacer(Modifier.height(28.dp))
        Text("Sources", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(10.dp))
        when {
            meta.type == "series" && selectedVideo == null -> Text("Choose an episode to find streams.")
            loadingSources -> CircularProgressIndicator(Modifier.size(30.dp))
            streams.isEmpty() -> Text("No direct-play streams were returned for this title.")
            else -> Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                streams.forEach { stream ->
                    FocusCard(text = "${stream.addonName}  ·  ${stream.title}") {
                        if (stream.external) {
                            runCatching {
                                context.startActivity(
                                    android.content.Intent(
                                        android.content.Intent.ACTION_VIEW,
                                        android.net.Uri.parse(stream.url),
                                    ).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK),
                                )
                            }
                            return@FocusCard
                        }
                        val playId = selectedVideo?.id ?: meta.id
                        onPlay(
                            StremioPlaybackRequest(
                                mediaKey = "stremio:${meta.type}:$playId",
                                streamUrl = stream.url,
                                title = selectedVideo?.let { "${meta.name} · ${it.title}" } ?: meta.name,
                                subtitles = subtitles,
                            ),
                        )
                    }
                }
                Text(
                    "${subtitles.size} external subtitle track${if (subtitles.size == 1) "" else "s"} available",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
        Spacer(Modifier.height(42.dp))
    }
}

@Composable
private fun MetaCard(meta: StremioMeta, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    val shape = RoundedCornerShape(10.dp)
    Column(
        Modifier.width(148.dp).scale(if (focused) 1.04f else 1f).clip(shape)
            .border(if (focused) 3.dp else 0.dp, MaterialTheme.colorScheme.primary, shape)
            .onFocusChanged { focused = it.isFocused }.clickable(onClick = onClick).focusable(),
    ) {
        AsyncImage(
            model = meta.poster,
            contentDescription = meta.name,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxWidth().height(if (meta.type == "tv") 148.dp else 216.dp)
                .background(MaterialTheme.colorScheme.surfaceVariant),
        )
        Text(
            meta.name,
            modifier = Modifier.padding(8.dp),
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
            style = MaterialTheme.typography.bodyMedium,
        )
    }
}

@Composable
private fun FocusCard(
    text: String,
    selected: Boolean = false,
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
) {
    var focused by remember { mutableStateOf(false) }
    val shape = RoundedCornerShape(8.dp)
    Box(
        modifier.clip(shape)
            .background(if (selected || focused) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant)
            .border(if (focused) 3.dp else 0.dp, MaterialTheme.colorScheme.primary, shape)
            .onFocusChanged { focused = it.isFocused }.clickable(onClick = onClick).focusable()
            .padding(horizontal = 16.dp, vertical = 13.dp),
    ) {
        Text(text, maxLines = 2, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun EmptyState(title: String, body: String, button: String, onClick: () -> Unit) {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(8.dp))
            Text(body, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(18.dp))
            Button(onClick = onClick) { Text(button) }
        }
    }
}

// Large metadata manifests can advertise 60+ catalogues. Loading 24×80 poster cards at once on a
// TV box is wasteful and was enough to trigger memory pressure. Keep the useful first shelves and
// let the image cache work for us; add-on management still retains every installed service.
private const val MAX_CATALOG_ROWS = 12
private const val MAX_ITEMS_PER_ROW = 40
