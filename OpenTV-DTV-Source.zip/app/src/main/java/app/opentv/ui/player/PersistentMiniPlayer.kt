/*
 * This file is part of OpenTV.
 * Copyright (C) 2026 The OpenTV Contributors
 * Licensed under the GNU General Public License v3.0 or later.
 */
package app.opentv.ui.player

import androidx.annotation.OptIn
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.util.UnstableApi
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import app.opentv.player.PlayerController

/**
 * The one app-wide live surface shown while the viewer browses elsewhere.
 *
 * It never creates a player or decoder: it merely moves the existing live [PlayerController]'s
 * surface into this card. Returning to full-screen moves that same surface back, so browsing
 * Movies, Shows or Settings cannot double the box's decoder load.
 */
@OptIn(UnstableApi::class)
@Composable
fun PersistentMiniPlayer(
    controller: PlayerController,
    title: String,
    isTelevision: Boolean,
    onExpand: () -> Unit,
    onStop: () -> Unit,
    modifier: Modifier = Modifier,
) {
    var focused by remember { mutableStateOf(false) }
    val shape = RoundedCornerShape(14.dp)
    Box(
        modifier
            .padding(20.dp)
            .width(if (isTelevision) 384.dp else 240.dp)
            .height(if (isTelevision) 216.dp else 135.dp)
            .clip(shape)
            .background(Color.Black)
            .border(if (focused) 4.dp else 1.dp, if (focused) MaterialTheme.colorScheme.primary else Color.DarkGray, shape)
            .onFocusChanged { focused = it.isFocused }
            .clickable(onClick = onExpand)
            .focusable(),
    ) {
        AndroidView(
            factory = { context ->
                PlayerView(context).apply {
                    useController = false
                    resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
                    player = controller.player
                    isFocusable = false
                    isClickable = false
                    keepScreenOn = true
                }
            },
            update = { it.player = controller.player },
            modifier = Modifier.fillMaxSize(),
        )
        Text(
            text = "LIVE · $title",
            maxLines = 1,
            color = Color.White,
            style = MaterialTheme.typography.labelLarge,
            modifier = Modifier
                .align(Alignment.BottomStart)
                .background(Color.Black.copy(alpha = 0.72f))
                .padding(horizontal = 12.dp, vertical = 7.dp),
        )
        IconButton(
            onClick = onStop,
            modifier = Modifier
                .align(Alignment.TopEnd)
                .background(Color.Black.copy(alpha = 0.68f), RoundedCornerShape(bottomStart = 10.dp)),
        ) {
            Icon(Icons.Default.Close, contentDescription = "Stop live TV", tint = Color.White)
        }
    }
}
