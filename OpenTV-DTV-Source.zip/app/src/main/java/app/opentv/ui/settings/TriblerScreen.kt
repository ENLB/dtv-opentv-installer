/*
 * This file is part of OpenTV.
 * Copyright (C) 2026 The OpenTV Contributors
 * Licensed under the GNU General Public License v3.0 or later.
 */
package app.opentv.ui.settings

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import app.opentv.core.ServiceLocator
import app.opentv.data.model.StremioPlaybackRequest
import app.opentv.data.remote.TriblerDownload
import app.opentv.data.remote.TriblerSearchResult
import kotlinx.coroutines.launch

@Composable
fun TriblerScreen(onBack: () -> Unit, onPlay: (StremioPlaybackRequest) -> Unit) {
    val context = LocalContext.current
    val graph = remember(context) { ServiceLocator.get(context) }
    val settings = graph.settings
    val scope = rememberCoroutineScope()
    var endpoint by remember { mutableStateOf(settings.triblerBaseUrl.value) }
    var key by remember { mutableStateOf(settings.triblerApiKey.value) }
    var hops by remember { mutableStateOf(settings.triblerHops.value) }
    var magnet by remember { mutableStateOf("") }
    var query by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("Not tested") }
    var busy by remember { mutableStateOf(false) }
    var downloads by remember { mutableStateOf<List<TriblerDownload>>(emptyList()) }
    var results by remember { mutableStateOf<List<TriblerSearchResult>>(emptyList()) }

    fun save() = settings.setTriblerConfig(endpoint, key, hops)
    fun run(block: suspend () -> Unit) {
        save()
        scope.launch {
            busy = true
            runCatching { block() }.onFailure { status = it.message ?: "Tribler request failed" }
            busy = false
        }
    }
    fun play(hash: String, fallbackTitle: String) = run {
        val (url, name) = graph.triblerClient.resolveExisting(endpoint, key, hash)
        onPlay(
            StremioPlaybackRequest(
                mediaKey = "tribler:$hash", streamUrl = url, title = name.ifBlank { fallbackTitle },
                subtitles = emptyList(), contentType = "movie",
            ),
        )
    }

    Column(Modifier.fillMaxSize().padding(horizontal = 32.dp, vertical = 24.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column {
                Text("Tribler", style = MaterialTheme.typography.headlineMedium)
                Text("Private P2P search, downloads and in-app streaming through your Tribler core")
            }
            Spacer(Modifier.weight(1f))
            OutlinedButton(onClick = { save(); onBack() }) { Text("Done") }
        }
        Spacer(Modifier.height(14.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.widthIn(max = 920.dp)) {
            item {
                OutlinedTextField(endpoint, { endpoint = it }, label = { Text("Tribler address") },
                    placeholder = { Text("http://192.168.0.10:64700") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            }
            item {
                OutlinedTextField(key, { key = it }, label = { Text("API key") }, singleLine = true,
                    visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
            }
            item {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Anonymous hops: $hops")
                    OutlinedButton(onClick = { hops = (hops - 1).coerceAtLeast(0) }) { Text("−") }
                    OutlinedButton(onClick = { hops = (hops + 1).coerceAtMost(3) }) { Text("+") }
                    Button(onClick = { run { status = "Connected to ${graph.triblerClient.version(endpoint, key)}" } }, enabled = endpoint.isNotBlank() && !busy) { Text("Test") }
                    OutlinedButton(onClick = { run { downloads = graph.triblerClient.downloads(endpoint, key); status = "${downloads.size} downloads" } }, enabled = endpoint.isNotBlank() && !busy) { Text("Refresh") }
                    if (busy) CircularProgressIndicator(Modifier.width(22.dp).height(22.dp), strokeWidth = 2.dp)
                }
                Text(status, color = if (status.startsWith("Connected")) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant)
                Text("0 hops is direct. One to three hops use Tribler's anonymous tunnel; safe seeding is forced on.", style = MaterialTheme.typography.bodySmall)
            }
            item {
                OutlinedTextField(magnet, { magnet = it }, label = { Text("Magnet, torrent URL or infohash") },
                    singleLine = true, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(6.dp))
                Button(onClick = { run {
                    val hash = graph.triblerClient.add(endpoint, key, magnet, hops)
                    status = "Added $hash"; downloads = graph.triblerClient.downloads(endpoint, key); magnet = ""
                } }, enabled = magnet.isNotBlank() && endpoint.isNotBlank() && !busy) { Text("Add to Tribler") }
            }
            item {
                OutlinedTextField(query, { query = it }, label = { Text("Search Tribler") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(6.dp))
                Button(onClick = { run { results = graph.triblerClient.search(endpoint, key, query); status = "${results.size} search results" } },
                    enabled = query.trim().length >= 2 && endpoint.isNotBlank() && !busy) { Text("Search") }
            }
            if (results.isNotEmpty()) item { Text("Search results", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }
            items(results, key = { "result:${it.infohash}" }) { result ->
                TriblerRow(result.name, "${formatBytes(result.size)} · ${result.seeders} seeders") {
                    run {
                        val hash = graph.triblerClient.add(endpoint, key, result.infohash, hops)
                        status = "Added ${result.name}"; downloads = graph.triblerClient.downloads(endpoint, key)
                    }
                }
            }
            if (downloads.isNotEmpty()) item { Text("Downloads", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }
            items(downloads, key = { "download:${it.infohash}" }) { download ->
                TriblerRow(download.name, "${(download.progress * 100).toInt()}% · ${download.status} · ${download.seeds} seeds · ${formatBytes(download.speed)}/s",
                    action = if (download.streamable) "Play" else "Files loading", enabled = download.streamable) {
                    play(download.infohash, download.name)
                }
            }
            item { Spacer(Modifier.height(28.dp)) }
        }
    }
}

@Composable
private fun TriblerRow(title: String, subtitle: String, action: String = "Add", enabled: Boolean = true, onClick: () -> Unit) {
    Card {
        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.SemiBold)
                Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Spacer(Modifier.width(12.dp))
            OutlinedButton(onClick = onClick, enabled = enabled) { Text(action) }
        }
    }
}

private fun formatBytes(value: Long): String = when {
    value >= 1_073_741_824L -> "%.1f GB".format(value / 1_073_741_824.0)
    value >= 1_048_576L -> "%.1f MB".format(value / 1_048_576.0)
    value >= 1024L -> "%.1f KB".format(value / 1024.0)
    else -> "$value B"
}
