/*
 * This file is part of OpenTV.
 * Copyright (C) 2026 The OpenTV Contributors
 * Licensed under the GNU General Public License v3.0 or later.
 */
package app.opentv.sync

import android.content.Context
import android.content.BroadcastReceiver
import android.content.Intent
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.util.Log
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import app.opentv.core.AppSettings
import app.opentv.core.ServiceLocator
import app.opentv.data.model.StremioAddon
import app.opentv.pairing.PairingHttp
import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.Inet4Address
import java.net.NetworkInterface
import java.net.ServerSocket
import java.net.URL
import java.util.concurrent.TimeUnit
import kotlin.concurrent.thread
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json

/** D TV is the local source of truth for portable Stremio add-on configuration. */
object PortableAddonSync {
    private const val MASTER_HOST = "192.168.0.84"
    private const val PORT = 18742
    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }
    @Volatile private var server: ServerSocket? = null

    @Serializable private data class Payload(val addons: List<StremioAddon>)

    fun start(context: Context) {
        if (isMaster()) {
            val settings = AppSettings.get(context)
            val prefs = context.getSharedPreferences("opentv", Context.MODE_PRIVATE)
            if (!prefs.getBoolean("dtv_interdimensional_addon_v1", false)) {
                settings.addStremioAddon(
                    StremioAddon(
                        LocalDtvContentServer.STREMIO_MANIFEST_URL,
                        "D TV — Interdimensional Cable",
                    ),
                )
                prefs.edit().putBoolean("dtv_interdimensional_addon_v1", true).apply()
            }
            val current = settings.stremioAddons.value
            if (current.any { it.manifestUrl.contains("enlb.github.io/d-tv-channels") }) {
                settings.replaceStremioAddons(
                    current.map {
                        if (it.manifestUrl.contains("enlb.github.io/d-tv-channels")) {
                            it.copy(manifestUrl = LocalDtvContentServer.STREMIO_MANIFEST_URL)
                        } else it
                    },
                )
            }
            startServer(context.applicationContext, settings)
        }
        schedule(context)
    }

    suspend fun pull(context: Context) = withContext(Dispatchers.IO) {
        if (isMaster()) return@withContext
        runCatching {
            val url = URL("http://$MASTER_HOST:$PORT/addons")
            // A device-wide VPN commonly blocks private-LAN peers. Use Android's underlying
            // Wi-Fi network for this local-only sync without changing or disconnecting the VPN.
            val connectivity = context.getSystemService(ConnectivityManager::class.java)
            val wifi = connectivity.allNetworks.firstOrNull { network ->
                connectivity.getNetworkCapabilities(network)
                    ?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true
            }
            val connection = (wifi?.openConnection(url) ?: url.openConnection()) as HttpURLConnection
            connection.connectTimeout = 3_000
            connection.readTimeout = 5_000
            connection.requestMethod = "GET"
            connection.inputStream.bufferedReader().use { reader ->
                val payload = json.decodeFromString(Payload.serializer(), reader.readText())
                AppSettings.get(context).replaceStremioAddons(payload.addons)
            }
            connection.disconnect()
        }.onFailure { Log.w("PortableAddonSync", "Could not pull D TV add-ons", it) }
    }

    fun accept(context: Context, body: String) {
        val payload = json.decodeFromString(Payload.serializer(), body)
        AppSettings.get(context).replaceStremioAddons(payload.addons)
    }

    private fun startServer(context: Context, settings: AppSettings) {
        if (server != null) return
        val socket = runCatching { ServerSocket(PORT) }.getOrNull() ?: return
        server = socket
        thread(name = "opentv-addon-sync", isDaemon = true) {
            while (!socket.isClosed) {
                val client = runCatching { socket.accept() }.getOrNull() ?: break
                runCatching {
                    if (!PairingHttp.isPrivateAddress(client.inetAddress?.hostAddress)) return@runCatching
                    val reader = BufferedReader(InputStreamReader(client.getInputStream(), Charsets.UTF_8))
                    val request = reader.readLine().orEmpty()
                    while (reader.readLine()?.isNotEmpty() == true) Unit
                    if (request.startsWith("GET /install.apk ")) {
                        val apk = File(context.applicationInfo.sourceDir)
                        val header = "HTTP/1.1 200 OK\r\n" +
                            "Content-Type: application/vnd.android.package-archive\r\n" +
                            "Content-Length: ${apk.length()}\r\n" +
                            "Content-Disposition: attachment; filename=OpenTV-DTV.apk\r\n" +
                            "Connection: close\r\n\r\n"
                        client.getOutputStream().write(header.toByteArray())
                        apk.inputStream().use { it.copyTo(client.getOutputStream()) }
                        client.getOutputStream().flush()
                    } else {
                        val body = if (request.startsWith("GET /addons ")) {
                            json.encodeToString(Payload.serializer(), Payload(settings.stremioAddons.value))
                        } else "{}"
                        client.getOutputStream().write(PairingHttp.httpResponse("200 OK", "application/json", body))
                    }
                }
                runCatching { client.close() }
            }
        }
    }

    private fun isMaster(): Boolean = runCatching {
        NetworkInterface.getNetworkInterfaces().toList().flatMap { it.inetAddresses.toList() }
            .filterIsInstance<Inet4Address>().any { it.hostAddress == MASTER_HOST }
    }.getOrDefault(false)

    private fun schedule(context: Context) {
        val request = PeriodicWorkRequestBuilder<PortableAddonSyncWorker>(15, TimeUnit.MINUTES)
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
            .build()
        WorkManager.getInstance(context).enqueueUniquePeriodicWork(
            "opentv-portable-addon-sync",
            ExistingPeriodicWorkPolicy.UPDATE,
            request,
        )
    }
}

class PortableAddonReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val body = intent.getStringExtra("payload") ?: return
        runCatching { PortableAddonSync.accept(context, body) }
            .onFailure { Log.w("PortableAddonSync", "Rejected sync bridge payload", it) }
    }
}

class PortableAddonSyncWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result {
        PortableAddonSync.pull(applicationContext)
        return Result.success()
    }
}
