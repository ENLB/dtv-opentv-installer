/*
 * This file is part of OpenTV.
 * Copyright (C) 2026 The OpenTV Contributors
 * Licensed under the GNU General Public License v3.0 or later.
 */
package app.opentv.sync

import android.content.Context
import android.util.Log
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.InetAddress
import java.net.ServerSocket
import java.net.URLDecoder
import kotlin.concurrent.thread

/**
 * Serves the bundled D TV playlist and guide to this app only.
 *
 * Binding to loopback is intentional: none of the channel configuration is exposed to the LAN or
 * internet. Every installed device carries the same snapshot and can browse it while the PC and
 * the original D TV are off.
 */
object LocalDtvContentServer {
    const val PORT = 18743
    const val PLAYLIST_URL = "http://127.0.0.1:$PORT/dtv.m3u8"
    const val GUIDE_URL = "http://127.0.0.1:$PORT/guide.xml.gz"

    @Volatile private var server: ServerSocket? = null

    fun start(context: Context) {
        if (server != null) return
        val socket = runCatching {
            ServerSocket(PORT, 8, InetAddress.getByName("127.0.0.1"))
        }.getOrElse {
            Log.e("LocalDtvContent", "Could not start private content server", it)
            return
        }
        server = socket
        val app = context.applicationContext
        thread(name = "opentv-private-content", isDaemon = true) {
            while (!socket.isClosed) {
                val client = runCatching { socket.accept() }.getOrNull() ?: break
                // Catalogue and EPG refreshes begin together. A single serial client loop let the
                // 7 MB guide transfer occupy the server while the playlist connection timed out.
                // Each loopback request gets its own tiny worker so neither can starve the other.
                thread(name = "opentv-private-content-client", isDaemon = true) {
                    runCatching {
                        client.soTimeout = 15_000
                        val reader = BufferedReader(InputStreamReader(client.getInputStream(), Charsets.UTF_8))
                        val request = reader.readLine().orEmpty()
                        while (reader.readLine()?.isNotEmpty() == true) Unit
                        val rawPath = request.split(' ').getOrNull(1)?.substringBefore('?').orEmpty()
                        val path = URLDecoder.decode(rawPath, "UTF-8").trimStart('/')
                        if (!request.startsWith("GET ") || path.isBlank() || path.contains("..")) {
                            respond(client.getOutputStream(), "400 Bad Request", "text/plain", "Bad request".toByteArray())
                        } else {
                            // aapt automatically expands and renames assets ending in .gz. Store the
                            // inner gzip stream under a neutral extension and keep the public loopback
                            // route conventional for the XMLTV downloader.
                            val assetPath = if (path == "guide.xml.gz") "guide.xmltvz" else path
                            val bytes = app.assets.open("dtv/$assetPath").use { it.readBytes() }
                            respond(client.getOutputStream(), "200 OK", mime(path), bytes)
                        }
                    }.onFailure {
                        runCatching {
                            respond(client.getOutputStream(), "404 Not Found", "text/plain", "Not found".toByteArray())
                        }
                    }
                    runCatching { client.close() }
                }
            }
        }
    }

    private fun respond(output: java.io.OutputStream, status: String, type: String, body: ByteArray) {
        output.write(
            ("HTTP/1.1 $status\r\nContent-Type: $type\r\nContent-Length: ${body.size}\r\n" +
                "Cache-Control: no-store\r\nConnection: close\r\n\r\n").toByteArray(),
        )
        output.write(body)
        output.flush()
    }

    private fun mime(path: String): String = when {
        path.endsWith(".json") -> "application/json"
        path.endsWith(".m3u8") -> "application/vnd.apple.mpegurl"
        path.endsWith(".xml.gz") || path.endsWith(".gz") -> "application/gzip"
        else -> "application/octet-stream"
    }
}
