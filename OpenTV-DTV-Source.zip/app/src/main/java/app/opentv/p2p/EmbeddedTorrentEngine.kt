package app.opentv.p2p

import android.content.Context
import com.frostwire.jlibtorrent.Priority
import com.frostwire.jlibtorrent.SessionManager
import com.frostwire.jlibtorrent.TorrentFlags
import com.frostwire.jlibtorrent.TorrentHandle
import com.frostwire.jlibtorrent.TorrentInfo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

/** On-device add-on P2P playback. No remote service, account, or external player is involved. */
class EmbeddedTorrentEngine private constructor(context: Context) {
    data class Stream(
        val id: String,
        val file: File,
        val size: Long,
        val fileIndex: Int,
        val info: TorrentInfo,
        val handle: TorrentHandle,
    )

    private val root = File(context.cacheDir, "p2p").apply { mkdirs() }
    private val session = SessionManager()
    private val startMutex = Mutex()
    private val streams = ConcurrentHashMap<String, Stream>()

    suspend fun prepare(rawMagnet: String): Pair<String, String> = withContext(Dispatchers.IO) {
        startMutex.withLock {
            if (!session.isRunning) session.start()
        }
        val magnet = normaliseMagnet(rawMagnet)
        // A missing/dead swarm must never trap the TV UI for minutes. Forty seconds is long
        // enough for DHT/tracker discovery on the Streamer while still giving the user a bounded,
        // predictable failure. The UI can be dismissed immediately while this native call winds
        // down in its IO worker.
        val metadata = session.fetchMagnet(magnet, METADATA_TIMEOUT_SECONDS, root)
            ?: error("No peers supplied torrent metadata within $METADATA_TIMEOUT_SECONDS seconds. Try another P2P source.")
        val info = TorrentInfo(metadata)
        require(info.isValid) { "The add-on returned invalid torrent metadata" }
        // android.net.Uri considers `magnet:` opaque and throws from getQueryParameter(). Parse
        // BEP-53's selected-file value directly instead; add-ons commonly append `&so=3`.
        val requested = Regex("(?:^|[?&])so=(\\d+)(?:&|$)", RegexOption.IGNORE_CASE)
            .find(magnet)?.groupValues?.get(1)?.toIntOrNull()
        val fileIndex = selectVideo(info, requested)
        val priorities = Array(info.numFiles()) { Priority.IGNORE }
        priorities[fileIndex] = Priority.SEVEN
        val downloadDir = File(root, info.infoHashV1().toHex()).apply { mkdirs() }
        session.download(info, downloadDir, null, priorities, null, TorrentFlags.SEQUENTIAL_DOWNLOAD)
        var handle: TorrentHandle? = null
        var attempts = 0
        while (handle?.isValid != true && attempts++ < 100) {
            handle = session.find(info)
            if (handle?.isValid != true) delay(100)
        }
        val validHandle = handle?.takeIf { it.isValid } ?: error("Could not start the on-device download")
        val relativePath = info.files().filePath(fileIndex)
        val file = File(downloadDir, relativePath)
        file.parentFile?.mkdirs()
        // Media3 may open the source before libtorrent's asynchronous add creates storage.
        // Creating the empty target is safe and removes that race; verified pieces are still the
        // only bytes TorrentDataSource will expose.
        if (!file.exists()) file.createNewFile()
        val id = UUID.randomUUID().toString()
        streams[id] = Stream(id, file, info.files().fileSize(fileIndex), fileIndex, info, validHandle)
        "optvp2p://$id" to file.name
    }

    fun stream(id: String): Stream? = streams[id]

    private fun selectVideo(info: TorrentInfo, requested: Int?): Int {
        if (requested != null && requested in 0 until info.numFiles()) return requested
        val video = setOf("mkv", "mp4", "m4v", "webm", "avi", "mov", "ts", "m2ts")
        return (0 until info.numFiles())
            .filter { info.files().filePath(it).substringAfterLast('.', "").lowercase() in video }
            .maxByOrNull { info.files().fileSize(it) }
            ?: error("This torrent does not contain a supported video file")
    }

    private fun normaliseMagnet(value: String): String {
        val trimmed = value.trim()
        if (trimmed.startsWith("magnet:?", true)) return trimmed
        require(trimmed.matches(Regex("(?i)[0-9a-f]{40}"))) { "The add-on did not return a valid magnet or info-hash" }
        return "magnet:?xt=urn:btih:$trimmed"
    }

    companion object {
        const val METADATA_TIMEOUT_SECONDS = 40
        @Volatile private var instance: EmbeddedTorrentEngine? = null
        fun get(context: Context): EmbeddedTorrentEngine = instance ?: synchronized(this) {
            instance ?: EmbeddedTorrentEngine(context.applicationContext).also { instance = it }
        }
    }
}
