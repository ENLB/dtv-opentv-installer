package app.opentv.p2p

import android.content.Context
import android.net.Uri
import com.frostwire.jlibtorrent.Priority
import com.frostwire.jlibtorrent.SessionManager
import com.frostwire.jlibtorrent.TorrentFlags
import com.frostwire.jlibtorrent.TorrentHandle
import com.frostwire.jlibtorrent.TorrentInfo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

/** On-device add-on P2P playback. No remote service, account, or external player is involved. */
class EmbeddedTorrentEngine private constructor(context: Context) {
    data class Stream(
        val id: String,
        val file: File,
        val size: Long,
        val fileIndex: Int,
        val info: TorrentInfo,
        val handle: TorrentHandle,
    )

    private val root = File(context.cacheDir, "p2p").apply { mkdirs() }
    private val session = SessionManager()
    private val startMutex = Mutex()
    private val streams = ConcurrentHashMap<String, Stream>()

    suspend fun prepare(rawMagnet: String): Pair<String, String> = withContext(Dispatchers.IO) {
        startMutex.withLock {
            if (!session.isRunning) session.start()
        }
        val magnet = normaliseMagnet(rawMagnet)
        val metadata = session.fetchMagnet(magnet, 90, root)
            ?: error("No peers returned torrent metadata within 90 seconds")
        val info = TorrentInfo(metadata)
        require(info.isValid) { "The add-on returned invalid torrent metadata" }
        val requested = Uri.parse(magnet).getQueryParameter("so")?.toIntOrNull()
        val fileIndex = selectVideo(info, requested)
        val priorities = Array(info.numFiles()) { Priority.IGNORE }
        priorities[fileIndex] = Priority.SEVEN
        val downloadDir = File(root, info.infoHashV1().toHex()).apply { mkdirs() }
        session.download(info, downloadDir, null, priorities, null, TorrentFlags.SEQUENTIAL_DOWNLOAD)
        var handle: TorrentHandle? = null
        var attempts = 0
        while (handle?.isValid != true && attempts++ < 100) {
            handle = session.find(info)
            if (handle?.isValid != true) delay(100)
        }
        val validHandle = handle?.takeIf { it.isValid } ?: error("Could not start the on-device download")
        val relativePath = info.files().filePath(fileIndex)
        val file = File(downloadDir, relativePath)
        file.parentFile?.mkdirs()
        val id = UUID.randomUUID().toString()
        streams[id] = Stream(id, file, info.files().fileSize(fileIndex), fileIndex, info, validHandle)
        "optvp2p://$id" to file.name
    }

    fun stream(id: String): Stream? = streams[id]

    private fun selectVideo(info: TorrentInfo, requested: Int?): Int {
        if (requested != null && requested in 0 until info.numFiles()) return requested
        val video = setOf("mkv", "mp4", "m4v", "webm", "avi", "mov", "ts", "m2ts")
        return (0 until info.numFiles())
            .filter { info.files().filePath(it).substringAfterLast('.', "").lowercase() in video }
            .maxByOrNull { info.files().fileSize(it) }
            ?: error("This torrent does not contain a supported video file")
    }

    private fun normaliseMagnet(value: String): String {
        val trimmed = value.trim()
        if (trimmed.startsWith("magnet:?", true)) return trimmed
        require(trimmed.matches(Regex("(?i)[0-9a-f]{40}"))) { "The add-on did not return a valid magnet or info-hash" }
        return "magnet:?xt=urn:btih:$trimmed"
    }

    companion object {
        @Volatile private var instance: EmbeddedTorrentEngine? = null
        fun get(context: Context): EmbeddedTorrentEngine = instance ?: synchronized(this) {
            instance ?: EmbeddedTorrentEngine(context.applicationContext).also { instance = it }
        }
    }
}
