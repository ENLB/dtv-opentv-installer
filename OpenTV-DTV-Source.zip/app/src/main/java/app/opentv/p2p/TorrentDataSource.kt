package app.opentv.p2p

import android.net.Uri
import androidx.media3.common.C
import androidx.media3.datasource.BaseDataSource
import androidx.media3.datasource.DataSource
import androidx.media3.datasource.DataSpec
import java.io.EOFException
import java.io.IOException
import java.io.RandomAccessFile

/** Media3 source which only exposes verified pieces from the growing on-device torrent file. */
class TorrentDataSource(private val engine: EmbeddedTorrentEngine) : BaseDataSource(false) {
    private var openedUri: Uri? = null
    private var stream: EmbeddedTorrentEngine.Stream? = null
    private var input: RandomAccessFile? = null
    private var position = 0L
    private var remaining = 0L

    override fun open(dataSpec: DataSpec): Long {
        transferInitializing(dataSpec)
        val item = engine.stream(dataSpec.uri.host.orEmpty()) ?: throw IOException("P2P stream expired; choose it again")
        stream = item
        openedUri = dataSpec.uri
        position = dataSpec.position
        remaining = if (dataSpec.length == C.LENGTH_UNSET.toLong()) item.size - position else dataSpec.length
        val deadline = System.currentTimeMillis() + 10_000
        while (!item.file.exists() && System.currentTimeMillis() < deadline) {
            try { Thread.sleep(100) } catch (e: InterruptedException) { Thread.currentThread().interrupt(); throw IOException(e) }
        }
        if (!item.file.exists()) throw IOException("P2P storage was not created")
        input = RandomAccessFile(item.file, "r")
        transferStarted(dataSpec)
        return remaining
    }

    override fun read(buffer: ByteArray, offset: Int, length: Int): Int {
        if (remaining == 0L) return C.RESULT_END_OF_INPUT
        val item = stream ?: return C.RESULT_END_OF_INPUT
        val wanted = minOf(length.toLong(), remaining).toInt()
        val deadline = System.currentTimeMillis() + 60_000
        while (!rangeAvailable(item, position, wanted)) {
            if (System.currentTimeMillis() >= deadline) throw IOException("Timed out waiting for peers")
            try { Thread.sleep(150) } catch (e: InterruptedException) { Thread.currentThread().interrupt(); throw IOException(e) }
        }
        val file = input ?: throw IOException("P2P file is closed")
        file.seek(position)
        val count = file.read(buffer, offset, wanted)
        if (count < 0) throw EOFException("Downloaded piece was not available on disk")
        position += count
        remaining -= count
        bytesTransferred(count)
        return count
    }

    private fun rangeAvailable(item: EmbeddedTorrentEngine.Stream, start: Long, count: Int): Boolean {
        if (!item.file.exists()) return false
        val first = item.info.mapFile(item.fileIndex, start, 1).piece()
        val lastOffset = (start + count - 1).coerceAtMost(item.size - 1)
        val last = item.info.mapFile(item.fileIndex, lastOffset, 1).piece()
        for (piece in first..last) if (!item.handle.havePiece(piece)) return false
        return item.file.length() >= minOf(item.size, start + count)
    }

    override fun getUri(): Uri? = openedUri
    override fun close() {
        input?.close(); input = null; stream = null; openedUri = null
        transferEnded()
    }

    class Factory(context: android.content.Context) : DataSource.Factory {
        private val engine = EmbeddedTorrentEngine.get(context)
        override fun createDataSource(): DataSource = TorrentDataSource(engine)
    }
}
