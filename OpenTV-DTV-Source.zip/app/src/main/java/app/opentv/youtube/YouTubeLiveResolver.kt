/*
 * This file is part of OpenTV.
 * Copyright (C) 2026 The OpenTV Contributors
 * Licensed under the GNU General Public License v3.0 or later.
 */
package app.opentv.youtube

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import org.schabi.newpipe.extractor.NewPipe
import org.schabi.newpipe.extractor.ServiceList
import org.schabi.newpipe.extractor.downloader.Downloader
import org.schabi.newpipe.extractor.downloader.Response
import org.schabi.newpipe.extractor.stream.StreamInfo

/** Resolves a stable official `/@channel/live` route to its current expiring HLS manifest. */
object YouTubeLiveResolver {
    private val initMutex = Mutex()
    @Volatile private var initialized = false

    suspend fun resolve(channelLiveUrl: String, client: OkHttpClient): String = withContext(Dispatchers.IO) {
        val page = client.newCall(
            Request.Builder()
                .url(channelLiveUrl)
                .header("User-Agent", USER_AGENT)
                .header("Accept-Language", "en-AU,en;q=0.9")
                .build(),
        ).execute().use { response ->
            check(response.isSuccessful) { "YouTube channel returned HTTP ${response.code}" }
            response.request.url to response.body?.string().orEmpty()
        }
        val (finalUrl, html) = page
        // Depending on region/cookies YouTube either redirects /live to watch?v=…, or serves a
        // mobile/desktop watch document in place. Support all three stable identifiers found in
        // those responses. The previous narrow `isLiveNow … externalVideoId` expression broke as
        // soon as YouTube reordered two JSON fields, which made every otherwise-working channel
        // fall out to an external app.
        val liveDocument = IS_LIVE.containsMatchIn(html)
        val videoId = finalUrl.queryParameter("v")
            ?: LIVE_VIDEO.find(html)?.groupValues?.get(1)
            ?: LIVE_VIDEO_REVERSED.find(html)?.groupValues?.get(1)
            ?: CANONICAL_VIDEO.find(html)?.groupValues?.get(1)
            ?: CANONICAL_JSON_VIDEO.find(html)?.groupValues?.get(1)
        if (!liveDocument && finalUrl.queryParameter("v") == null) {
            error("This channel is not live right now")
        }
        val playableId = videoId
            ?: error("This channel is not live right now")
        ensureInitialized(client)
        val info = StreamInfo.getInfo(ServiceList.YouTube, "https://www.youtube.com/watch?v=$playableId")
        info.hlsUrl.takeIf { it.isNotBlank() }
            ?: error("YouTube did not provide a playable live HLS stream")
    }

    private suspend fun ensureInitialized(client: OkHttpClient) {
        if (initialized) return
        initMutex.withLock {
            if (!initialized) {
                NewPipe.init(OkHttpDownloader(client))
                initialized = true
            }
        }
    }

    private class OkHttpDownloader(private val client: OkHttpClient) : Downloader() {
        override fun execute(request: org.schabi.newpipe.extractor.downloader.Request): Response {
            val body = request.dataToSend()?.toRequestBody()
            val builder = Request.Builder()
                .url(request.url())
                .method(request.httpMethod(), body)
                .header("User-Agent", USER_AGENT)
            request.headers().forEach { (name, values) ->
                builder.removeHeader(name)
                values.forEach { builder.addHeader(name, it) }
            }
            client.newCall(builder.build()).execute().use { response ->
                return Response(
                    response.code,
                    response.message,
                    response.headers.toMultimap(),
                    response.body?.string(),
                    response.request.url.toString(),
                )
            }
        }
    }

    // The /live page's player response puts this flag immediately before externalVideoId.
    private val IS_LIVE = Regex("\\\"isLiveNow\\\"\\s*:\\s*true")
    private val LIVE_VIDEO = Regex(
        "\\\"isLiveNow\\\"\\s*:\\s*true.{0,8000}?\\\"externalVideoId\\\"\\s*:\\s*\\\"([A-Za-z0-9_-]{11})\\\"",
    )
    private val LIVE_VIDEO_REVERSED = Regex(
        "\\\"externalVideoId\\\"\\s*:\\s*\\\"([A-Za-z0-9_-]{11})\\\".{0,8000}?\\\"isLiveNow\\\"\\s*:\\s*true",
    )
    private val CANONICAL_VIDEO = Regex(
        "<link[^>]+rel=[\\\"']canonical[\\\"'][^>]+href=[\\\"']https?://(?:www\\.)?youtube\\.com/watch\\?v=([A-Za-z0-9_-]{11})",
        RegexOption.IGNORE_CASE,
    )
    private val CANONICAL_JSON_VIDEO = Regex(
        "\\\"canonicalUrl\\\"\\s*:\\s*\\\"https://(?:www\\.)?youtube\\.com/watch\\?v=([A-Za-z0-9_-]{11})",
    )
    private const val USER_AGENT =
        "Mozilla/5.0 (Linux; Android 14; TV) AppleWebKit/537.36 Chrome/131.0 Safari/537.36"
}
