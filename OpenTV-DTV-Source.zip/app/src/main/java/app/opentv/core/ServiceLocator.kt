/*
 * This file is part of OpenTV.
 * Copyright (C) 2026 The OpenTV Contributors
 * Licensed under the GNU General Public License v3.0 or later.
 */
package app.opentv.core

import android.content.Context
import app.opentv.data.db.OpenTvDatabase
import app.opentv.data.remote.StalkerApi
import app.opentv.data.remote.StremioClient
import app.opentv.data.remote.TriblerClient
import app.opentv.data.remote.XtreamApi
import app.opentv.data.repo.CatalogRepository
import app.opentv.data.repo.EpgRepository
import app.opentv.data.repo.RecordingRepository
import app.opentv.data.repo.ReminderRepository
import app.opentv.data.repo.SourceRepository
import app.opentv.recording.RecordingEngine
import java.util.concurrent.TimeUnit
import okhttp3.OkHttpClient
import okhttp3.Dns
import java.net.InetAddress
import java.net.Inet4Address

/**
 * Hand-rolled dependency container.
 *
 * Hilt would be the conventional choice. It is deliberately not used: it adds an annotation
 * processor, a build-time graph, and a class of error message that is genuinely hard to read,
 * in exchange for wiring roughly a dozen objects. For a project whose main hope is drive-by
 * contributions from people fixing their own bugs, "you can read the whole graph in one file"
 * is worth more than the ceremony.
 */
object ServiceLocator {

    @Volatile private var instance: Graph? = null

    fun get(context: Context): Graph =
        instance ?: synchronized(this) {
            instance ?: Graph(context.applicationContext).also { instance = it }
        }

    class Graph(context: Context) {
        private val appContext = context.applicationContext

        val settings: AppSettings by lazy { AppSettings.get(appContext) }

        val database: OpenTvDatabase by lazy { OpenTvDatabase.build(context) }

        val httpClient: OkHttpClient by lazy {
            // Keep device-wide ad blocking. If it rejects one of the small, user-selected metadata,
            // trailer or subtitle services, use that service's known anycast edge addresses. TLS
            // still validates the original hostname; no credentials or clear-text requests are used.
            val resilientDns = object : Dns {
                override fun lookup(hostname: String): List<InetAddress> =
                    DirectFallbackDns.lookupKnown(hostname)
                        ?: Dns.SYSTEM.lookup(hostname)
            }
            OkHttpClient.Builder()
                .dns(resilientDns)
                .connectTimeout(15, TimeUnit.SECONDS)
                // Generous: catalogue endpoints on a busy panel can take a long time to
                // produce 40,000 rows, and timing out mid-list is worse than waiting.
                .readTimeout(60, TimeUnit.SECONDS)
                .callTimeout(5, TimeUnit.MINUTES)
                .retryOnConnectionFailure(true)
                .followRedirects(true)
                .build()
        }

        /**
         * A separate client for the player's data source. A live stream is an effectively
         * infinite HTTP response body, so the catalogue client's five-minute [callTimeout] would
         * guillotine every live channel at that mark — here there is no overall call timeout, only
         * a read timeout that catches a genuinely dead connection. Cross-protocol redirects are
         * followed explicitly because IPTV stream URLs routinely bounce http→https onto a CDN, and
         * a client that stops at the redirect surfaces as "lost connection to server".
         */
        val streamingHttpClient: OkHttpClient by lazy {
            // Some home routers advertise IPv6 DNS answers even though their IPv6 route is
            // unusable. OkHttp then waits on that black hole and the player appears to buffer
            // forever. Prefer IPv4 for streams while retaining IPv6 as an automatic fallback.
            val playbackDns = object : Dns {
                override fun lookup(hostname: String): List<InetAddress> =
                    httpClient.dns.lookup(hostname).sortedByDescending { it is Inet4Address }
            }
            httpClient.newBuilder()
                .dns(playbackDns)
                .callTimeout(0, TimeUnit.MILLISECONDS)
                // Dead public streams used to hold the player for 15–30 seconds per attempt and
                // were then retried repeatedly, making a failed channel look like an app crash.
                // Live HLS segments normally arrive well inside this window; a genuinely stalled
                // endpoint now gives the viewer an answer quickly.
                .connectTimeout(7, TimeUnit.SECONDS)
                .readTimeout(15, TimeUnit.SECONDS)
                .followRedirects(true)
                .followSslRedirects(true)
                .retryOnConnectionFailure(true)
                .build()
        }

        val xtreamApi: XtreamApi by lazy { XtreamApi(httpClient) }

        /** Stalker / Ministra portal client (MAC handshake + create_link). */
        val stalkerApi: StalkerApi by lazy { StalkerApi(httpClient) }

        /** Neutral Stremio add-on protocol client. Talks only to user-added manifest URLs. */
        val stremioClient: StremioClient by lazy { StremioClient(httpClient) }
        val triblerClient: TriblerClient by lazy { TriblerClient(streamingHttpClient) }

        val sourceRepository: SourceRepository by lazy {
            SourceRepository(database.sources(), xtreamApi, stalkerApi)
        }

        val catalogRepository: CatalogRepository by lazy {
            CatalogRepository(
                sourceDao = database.sources(),
                channelDao = database.channels(),
                categoryDao = database.categories(),
                movieDao = database.movies(),
                seriesDao = database.series(),
                episodeDao = database.episodes(),
                positionDao = database.positions(),
                api = xtreamApi,
                stalkerApi = stalkerApi,
                http = httpClient,
                settings = settings,
            )
        }

        val epgRepository: EpgRepository by lazy {
            EpgRepository(
                programmeDao = database.programmes(),
                feedDao = database.epgFeeds(),
                aliasDao = database.epgAliases(),
                channelDao = database.channels(),
                sourceDao = database.sources(),
                api = xtreamApi,
                http = httpClient,
            )
        }

        val playbackPositions get() = database.positions()

        val profiles get() = database.profiles()

        val recordingRepository: RecordingRepository by lazy {
            RecordingRepository(database.recordings(), database.seriesRules())
        }

        val reminderRepository: ReminderRepository by lazy {
            ReminderRepository(database.reminders())
        }

        val recordingEngine: RecordingEngine by lazy {
            RecordingEngine(
                appContext, recordingRepository, sourceRepository, settings,
                database.channels(), epgRepository,
            )
        }
    }

    private object DirectFallbackDns {
        // Cloudflare anycast edges used by these public services. This list is deliberately narrow;
        // ordinary channels and browsing always use Android's configured Private DNS.
        private val addresses = mapOf(
            "v3-cinemeta.strem.io" to listOf("104.17.88.107", "104.17.89.107"),
            "aiometadata.elfhosted.com" to listOf("104.26.9.49", "172.67.74.162", "104.26.8.49"),
            "87d6a6ef6b58-webstreamrmbg.baby-beamup.club" to listOf("172.67.222.90", "104.21.94.103"),
            "streailer.elfhosted.com" to listOf("172.67.74.162", "104.26.8.49", "104.26.9.49"),
            "subsense.nepiraw.com" to listOf("104.21.57.42", "172.67.189.31"),
            "opensubtitlesv3-pro.dexter21767.com" to listOf("172.67.195.253", "104.21.21.22"),
            "opensubtitles-v3.strem.io" to listOf("104.17.89.107", "104.17.88.107"),
            "watchhub.strem.io" to listOf("104.17.89.107", "104.17.88.107"),
        )

        fun lookupKnown(hostname: String): List<InetAddress>? =
            addresses[hostname.lowercase()]?.map(InetAddress::getByName)
    }
}
