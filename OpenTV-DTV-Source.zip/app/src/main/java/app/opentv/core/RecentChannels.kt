/*
 * This file is part of OpenTV.
 * Copyright (C) 2026 The OpenTV Contributors
 * Licensed under the GNU General Public License v3.0 or later.
 */
package app.opentv.core

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray

/** Durable, device-local history of the last 100 distinct live channels actually tuned. */
object RecentChannels {
    private const val PREFS = "opentv_recent_channels"
    private const val KEY_URLS = "urls"
    const val LIMIT = 100

    private val _urls = MutableStateFlow<List<String>>(emptyList())
    val urls: StateFlow<List<String>> = _urls.asStateFlow()
    private var loaded = false

    @Synchronized
    fun initialise(context: Context) {
        if (loaded) return
        val encoded = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_URLS, "[]") ?: "[]"
        _urls.value = runCatching {
            val array = JSONArray(encoded)
            List(array.length()) { array.getString(it) }
                .filter(String::isNotBlank).distinct().take(LIMIT)
        }.getOrDefault(emptyList())
        loaded = true
    }

    @Synchronized
    fun record(context: Context, streamUrl: String) {
        if (streamUrl.isBlank()) return
        initialise(context)
        val updated = moveToFront(_urls.value, streamUrl)
        if (updated == _urls.value) return
        _urls.value = updated
        context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(KEY_URLS, JSONArray(updated).toString()).apply()
    }

    @Synchronized
    fun remove(context: Context, streamUrls: Collection<String>) {
        initialise(context)
        if (streamUrls.isEmpty()) return
        val removed = streamUrls.toHashSet()
        val updated = _urls.value.filterNot(removed::contains)
        if (updated == _urls.value) return
        _urls.value = updated
        context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(KEY_URLS, JSONArray(updated).toString()).apply()
    }

    internal fun moveToFront(current: List<String>, streamUrl: String): List<String> =
        buildList {
            add(streamUrl)
            current.asSequence().filter { it != streamUrl }.take(LIMIT - 1).forEach(::add)
        }
}
