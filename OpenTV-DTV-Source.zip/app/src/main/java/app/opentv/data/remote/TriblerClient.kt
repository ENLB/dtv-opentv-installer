/*
 * This file is part of OpenTV.
 * Copyright (C) 2026 The OpenTV Contributors
 * Licensed under the GNU General Public License v3.0 or later.
 */
package app.opentv.data.remote

import java.net.URI
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.booleanOrNull
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.doubleOrNull
import kotlinx.serialization.json.intOrNull
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody

data class TriblerDownload(
    val infohash: String,
    val name: String,
    val progress: Double,
    val status: String,
    val seeds: Int,
    val peers: Int,
    val speed: Long,
    val streamable: Boolean,
)

data class TriblerFile(val index: Int, val name: String, val size: Long, val progress: Double)
data class TriblerSearchResult(val infohash: String, val name: String, val size: Long, val seeders: Int)

/** Thin client for Tribler 8's public REST API; OpenTV never embeds or impersonates its core. */
class TriblerClient(private val http: OkHttpClient) {
    private val json = Json { ignoreUnknownKeys = true }

    suspend fun version(baseUrl: String, key: String): String =
        get(baseUrl, key, "/api/versioning/versions/current").string("version") ?: "Tribler"

    suspend fun downloads(baseUrl: String, key: String): List<TriblerDownload> =
        get(baseUrl, key, "/api/downloads")["downloads"]?.jsonArray.orEmpty().mapNotNull { value ->
            val o = value.jsonObject
            val hash = o.string("infohash") ?: return@mapNotNull null
            TriblerDownload(
                hash, o.string("name") ?: hash, o.double("progress"), o.string("status") ?: "UNKNOWN",
                o.int("num_seeds"), o.int("num_peers"), o.long("speed_down"),
                o["streamable"]?.jsonPrimitive?.booleanOrNull == true,
            )
        }

    suspend fun add(baseUrl: String, key: String, raw: String, hops: Int): String {
        val uri = normalizeMagnet(raw)
        val body = """{"uri":${quote(uri)},"anon_hops":${hops.coerceIn(0, 3)},"safe_seeding":${hops > 0}}"""
        val result = request(baseUrl, key, "/api/downloads", "PUT", body)
        return result.string("infohash") ?: infohash(uri)
            ?: error(result.errorMessage() ?: "Tribler did not return an infohash")
    }

    suspend fun files(baseUrl: String, key: String, hash: String): List<TriblerFile> =
        get(baseUrl, key, "/api/downloads/$hash/files")["files"]?.jsonArray.orEmpty().mapNotNull { value ->
            val o = value.jsonObject
            TriblerFile(o.int("index"), o.string("name") ?: return@mapNotNull null, o.long("size"), o.double("progress"))
        }

    /** Wait for magnet metadata, then return the requested file or the largest video. */
    suspend fun resolveStream(baseUrl: String, key: String, raw: String, hops: Int): Pair<String, String> {
        val hash = add(baseUrl, key, raw, hops)
        val requested = runCatching { URI(raw).rawQuery?.split('&')?.firstOrNull { it.startsWith("so=") }
            ?.substringAfter('=')?.toIntOrNull() }.getOrNull()
        repeat(60) {
            val files = runCatching { files(baseUrl, key, hash) }.getOrDefault(emptyList())
            val chosen = requested?.let { index -> files.firstOrNull { it.index == index } }
                ?: files.filter { it.isVideo() }.maxByOrNull { it.size }
            if (chosen != null) return streamUrl(baseUrl, key, hash, chosen.index) to chosen.name
            delay(1_500)
        }
        error("Tribler could not obtain torrent metadata within 90 seconds")
    }

    suspend fun resolveExisting(baseUrl: String, key: String, hash: String): Pair<String, String> {
        val chosen = files(baseUrl, key, hash).filter { it.isVideo() }.maxByOrNull { it.size }
            ?: error("This download has no supported video file yet")
        return streamUrl(baseUrl, key, hash, chosen.index) to chosen.name
    }

    suspend fun search(baseUrl: String, key: String, query: String): List<TriblerSearchResult> {
        val q = java.net.URLEncoder.encode(query.trim(), "UTF-8")
        // Start peer search, then briefly allow arriving results to enter Tribler's local index.
        runCatching { request(baseUrl, key, "/api/search/remote?fts_text=$q&popular=0&metadata_type=300&exclude_deleted=1", "PUT") }
        delay(1_500)
        return get(baseUrl, key, "/api/metadata/search/local?first=1&last=100&metadata_type=300&exclude_deleted=1&fts_text=$q")
            .get("results")?.jsonArray.orEmpty().mapNotNull { value ->
                val o = value.jsonObject
                val hash = o.string("infohash") ?: return@mapNotNull null
                TriblerSearchResult(hash, o.string("name") ?: hash, o.long("size"), o.int("num_seeders"))
            }
    }

    fun streamUrl(baseUrl: String, key: String, hash: String, index: Int): String {
        val root = baseUrl.trim().trimEnd('/')
        val auth = if (key.isBlank()) "" else "?key=${java.net.URLEncoder.encode(key, "UTF-8")}"
        return "$root/api/downloads/$hash/stream/$index$auth"
    }

    private suspend fun get(base: String, key: String, path: String) = request(base, key, path, "GET")

    private suspend fun request(base: String, key: String, path: String, method: String, body: String? = null): JsonObject =
        withContext(Dispatchers.IO) {
            require(base.startsWith("http://") || base.startsWith("https://")) { "Use an http:// or https:// Tribler address" }
            val builder = Request.Builder().url(base.trim().trimEnd('/') + path).header("Accept", "application/json")
            if (key.isNotBlank()) builder.header("X-Api-Key", key)
            val requestBody = body?.toRequestBody("application/json".toMediaType())
            when (method) { "PUT" -> builder.put(requestBody ?: ByteArray(0).toRequestBody()); else -> builder.get() }
            http.newCall(builder.build()).execute().use { response ->
                val text = response.body?.string().orEmpty()
                val parsed = runCatching { json.parseToJsonElement(text).jsonObject }.getOrNull()
                if (!response.isSuccessful) error(parsed?.errorMessage() ?: "Tribler returned HTTP ${response.code}")
                parsed ?: JsonObject(emptyMap())
            }
        }

    companion object {
        fun normalizeMagnet(raw: String): String {
            val value = raw.trim()
            if (value.startsWith("magnet:?", true) || value.startsWith("http://") || value.startsWith("https://")) return value
            require(value.matches(Regex("(?i)[a-f0-9]{40}|[a-z2-7]{32}"))) { "Paste a magnet link, torrent URL or raw infohash" }
            return "magnet:?xt=urn:btih:$value"
        }
        fun infohash(magnet: String): String? = Regex("(?i)urn:btih:([a-f0-9]{40}|[a-z2-7]{32})")
            .find(magnet)?.groupValues?.get(1)?.lowercase()
        private fun quote(value: String) = kotlinx.serialization.json.JsonPrimitive(value).toString()
    }
}

private fun TriblerFile.isVideo() = name.substringAfterLast('.', "").lowercase() in
    setOf("mp4", "m4v", "mov", "mkv", "webm", "avi", "ts", "m2ts")
private fun JsonObject.string(key: String) = this[key]?.jsonPrimitive?.contentOrNull
private fun JsonObject.int(key: String) = this[key]?.jsonPrimitive?.intOrNull ?: 0
private fun JsonObject.long(key: String) = this[key]?.jsonPrimitive?.contentOrNull?.toLongOrNull() ?: 0L
private fun JsonObject.double(key: String) = this[key]?.jsonPrimitive?.doubleOrNull ?: 0.0
private fun JsonObject.errorMessage(): String? = this["error"]?.let { e ->
    runCatching { e.jsonObject.string("message") }.getOrNull() ?: e.jsonPrimitive.contentOrNull
}
