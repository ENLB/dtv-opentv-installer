/*
 * This file is part of OpenTV.
 * Copyright (C) 2026 The OpenTV Contributors
 * Licensed under the GNU General Public License v3.0 or later.
 */
package app.opentv.data.model

import kotlinx.serialization.Serializable

/**
 * A user-added Stremio add-on: a small web service (identified by its manifest URL) that, given a
 * title, returns playable stream links. OpenTV ships with none — the user pastes the manifest URL
 * of an add-on they have configured themselves (including any debrid key, which is baked into that
 * personalised URL on the add-on's own site, never entered into OpenTV). Stored on-device only,
 * exactly like a provider credential.
 *
 * This is the same open protocol Stremio and Kodi speak; OpenTV is only a neutral client for it and
 * hosts, indexes and bundles no content of its own.
 */
@Serializable
data class StremioAddon(
    /** The manifest URL the user pasted, e.g. https://…/manifest.json. Its identity for de-dup. */
    val manifestUrl: String,
    /** Display name read from the add-on's manifest at add time. */
    val name: String,
    /** Disabled add-ons remain configured but make no network requests and return no results. */
    val enabled: Boolean = true,
    val version: String? = null,
    val resources: Set<String> = emptySet(),
    val configurable: Boolean = false,
    val p2p: Boolean = false,
    val adult: Boolean = false,
)

/**
 * A single playable stream an add-on returned for a title. Direct URLs play internally. A valid
 * protocol `infoHash` is represented as a magnet [url] and handed to a user-installed P2P engine;
 * OpenTV does not start peer participation silently.
 */
data class StremioStream(
    val url: String,
    /** A human label for the quality/source line the add-on supplied (e.g. "4K • 12GB"). */
    val title: String,
    /** Which add-on produced this, for grouping in the picker. */
    val addonName: String,
    /** Explicit external URLs leave the app; documented `ytId` results resolve in OpenTV. */
    val external: Boolean = false,
    /** True when [url] is a magnet hand-off constructed from the protocol's infoHash/fileIdx. */
    val p2p: Boolean = false,
    /** HTTP headers requested by the add-on's documented behaviorHints.proxyHeaders block. */
    val requestHeaders: Map<String, String> = emptyMap(),
)

/** A catalogue row advertised by a Stremio manifest. */
data class StremioCatalog(
    val manifestUrl: String,
    val addonName: String,
    val type: String,
    val id: String,
    val name: String,
    /** Extra arguments advertised by the manifest, e.g. search, genre, skip or date. */
    val extras: Set<String> = emptySet(),
)

/** Lightweight or full metadata returned by catalog/meta resources. */
data class StremioMeta(
    val id: String,
    val type: String,
    val name: String,
    val poster: String? = null,
    val background: String? = null,
    val description: String? = null,
    val releaseInfo: String? = null,
    val genres: List<String> = emptyList(),
    val imdbRating: String? = null,
    val videos: List<StremioVideo> = emptyList(),
)

/** One playable episode advertised in a series meta response. */
data class StremioVideo(
    val id: String,
    val title: String,
    val season: Int? = null,
    val episode: Int? = null,
    val thumbnail: String? = null,
)

/** An external subtitle track returned by a Stremio subtitles resource. */
@Serializable
data class StremioSubtitle(
    val url: String,
    val language: String,
    val label: String,
)

/** In-memory hand-off to the player, avoiding very long subtitle URLs in a navigation route. */
data class StremioPlaybackRequest(
    val mediaKey: String,
    val streamUrl: String,
    val title: String,
    val subtitles: List<StremioSubtitle>,
    val requestHeaders: Map<String, String> = emptyMap(),
    val posterUrl: String? = null,
    val contentType: String = "movie",
)

/** Persisted display data used to resolve add-on progress into a Keep Watching card. */
@Serializable
data class StremioResumeMetadata(
    val title: String,
    val posterUrl: String? = null,
    val streamUrl: String,
    val contentType: String,
    val subtitles: List<StremioSubtitle> = emptyList(),
    val requestHeaders: Map<String, String> = emptyMap(),
)

object StremioPlaybackRequests {
    private const val MAX_REQUESTS = 8
    private val requests = linkedMapOf<String, StremioPlaybackRequest>()

    @Synchronized
    fun put(request: StremioPlaybackRequest): String {
        val token = java.util.UUID.randomUUID().toString()
        requests[token] = request
        while (requests.size > MAX_REQUESTS) requests.remove(requests.keys.first())
        return token
    }

    @Synchronized
    fun get(token: String): StremioPlaybackRequest? = requests[token]
}

/** Short-lived detail-page hand-off; avoids serialising complete add-on metadata into a route. */
object StremioSelections {
    private const val MAX_SELECTIONS = 16
    private val selections = linkedMapOf<String, Pair<StremioCatalog, StremioMeta>>()

    @Synchronized
    fun put(catalog: StremioCatalog, meta: StremioMeta): String {
        val token = java.util.UUID.randomUUID().toString()
        selections[token] = catalog to meta
        while (selections.size > MAX_SELECTIONS) selections.remove(selections.keys.first())
        return token
    }

    @Synchronized
    fun get(token: String): Pair<StremioCatalog, StremioMeta>? = selections[token]
}
