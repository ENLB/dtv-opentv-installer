/*
 * This file is part of OpenTV.
 * Copyright (C) 2026 The OpenTV Contributors
 * Licensed under the GNU General Public License v3.0 or later.
 */
package app.opentv.data.model

import kotlinx.serialization.Serializable

/**
 * A user-added Stremio add-on: a small web service (identified by its manifest URL) that, given a
 * title, returns playable stream links. OpenTV ships with none — the user pastes the manifest URL
 * of an add-on they have configured themselves (including any debrid key, which is baked into that
 * personalised URL on the add-on's own site, never entered into OpenTV). Stored on-device only,
 * exactly like a provider credential.
 *
 * This is the same open protocol Stremio and Kodi speak; OpenTV is only a neutral client for it and
 * hosts, indexes and bundles no content of its own.
 */
@Serializable
data class StremioAddon(
    /** The manifest URL the user pasted, e.g. https://…/manifest.json. Its identity for de-dup. */
    val manifestUrl: String,
    /** Display name read from the add-on's manifest at add time. */
    val name: String,
)

/**
 * A single playable stream an add-on returned for a title. OpenTV keeps only streams that carry a
 * direct, ready-to-play [url] (what debrid-backed add-ons return); raw torrent (infoHash-only)
 * entries are dropped, because OpenTV plays URLs and deliberately does no torrenting itself.
 */
data class StremioStream(
    val url: String,
    /** A human label for the quality/source line the add-on supplied (e.g. "4K • 12GB"). */
    val title: String,
    /** Which add-on produced this, for grouping in the picker. */
    val addonName: String,
    /** Web/YouTube results are handed to an installed browser/player instead of ExoPlayer. */
    val external: Boolean = false,
)

/** A catalogue row advertised by a Stremio manifest. */
data class StremioCatalog(
    val manifestUrl: String,
    val addonName: String,
    val type: String,
    val id: String,
    val name: String,
)

/** Lightweight or full metadata returned by catalog/meta resources. */
data class StremioMeta(
    val id: String,
    val type: String,
    val name: String,
    val poster: String? = null,
    val background: String? = null,
    val description: String? = null,
    val releaseInfo: String? = null,
    val genres: List<String> = emptyList(),
    val imdbRating: String? = null,
    val videos: List<StremioVideo> = emptyList(),
)

/** One playable episode advertised in a series meta response. */
data class StremioVideo(
    val id: String,
    val title: String,
    val season: Int? = null,
    val episode: Int? = null,
    val thumbnail: String? = null,
)

/** An external subtitle track returned by a Stremio subtitles resource. */
data class StremioSubtitle(
    val url: String,
    val language: String,
    val label: String,
)

/** In-memory hand-off to the player, avoiding very long subtitle URLs in a navigation route. */
data class StremioPlaybackRequest(
    val mediaKey: String,
    val streamUrl: String,
    val title: String,
    val subtitles: List<StremioSubtitle>,
)

object StremioPlaybackRequests {
    private const val MAX_REQUESTS = 8
    private val requests = linkedMapOf<String, StremioPlaybackRequest>()

    @Synchronized
    fun put(request: StremioPlaybackRequest): String {
        val token = java.util.UUID.randomUUID().toString()
        requests[token] = request
        while (requests.size > MAX_REQUESTS) requests.remove(requests.keys.first())
        return token
    }

    @Synchronized
    fun get(token: String): StremioPlaybackRequest? = requests[token]
}
