/*
 * This file is part of OpenTV.
 * Copyright (C) 2026 The OpenTV Contributors
 * Licensed under the GNU General Public License v3.0 or later.
 */
package app.opentv.data.remote

import android.util.Log
import app.opentv.data.model.StremioCatalog
import app.opentv.data.model.StremioMeta
import app.opentv.data.model.StremioSubtitle
import app.opentv.data.model.StremioStream
import app.opentv.data.model.StremioVideo
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.intOrNull
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import okhttp3.HttpUrl
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import java.net.URLEncoder
import java.nio.charset.StandardCharsets
import java.util.concurrent.TimeUnit

/**
 * A thin, read-only client for the open Stremio add-on protocol — the same protocol Stremio and
 * many Kodi add-ons speak. OpenTV ships with no add-ons and hosts no content; this only talks to
 * manifest URLs the user has pasted in themselves.
 *
 * ## What it does
 * - [fetchManifest] fetches an add-on's `manifest.json` and returns its display name if it looks
 *   like a real add-on (has an id + name), so the settings screen can validate a pasted URL.
 * - [streams] supports direct URLs, external URLs, YouTube IDs and the documented infoHash/fileIdx
 *   torrent descriptor. P2P descriptors become an explicit magnet hand-off to an installed engine;
 *   direct streams continue through OpenTV's internal player.
 *
 * ## Blocking on purpose
 * Methods block on the calling thread; callers already run them inside `withContext(Dispatchers.IO)`,
 * matching [TmdbClient].
 */
class StremioClient(
    private val http: OkHttpClient,
    private val json: Json = Json { ignoreUnknownKeys = true; isLenient = true },
) {

    data class Manifest(
        val name: String,
        val version: String?,
        val resources: Set<String>,
        val catalogs: List<StremioCatalog>,
        val configurable: Boolean,
        val configurationRequired: Boolean,
        val p2p: Boolean,
        val adult: Boolean,
    )

    /**
     * Fetch and lightly validate an add-on manifest. Returns the add-on's display name, or null if
     * the URL doesn't resolve to something that looks like a Stremio manifest (id + name present).
     */
    fun fetchManifest(manifestUrl: String): String? = manifest(manifestUrl)?.name

    /** Fetch the capabilities and catalogue rows advertised by an add-on. */
    fun manifest(manifestUrl: String): Manifest? {
        try {
            val url = manifestUrl.trim().toHttpUrlOrNull() ?: return null
            val o = get(url)?.jsonObject ?: return null
            val name = o["name"]?.jsonPrimitive?.contentOrNull?.takeIf { it.isNotBlank() } ?: return null
            val hasId = o["id"]?.jsonPrimitive?.contentOrNull?.isNotBlank() == true
            if (!hasId) return null
            val resources = o["resources"]?.jsonArray.orEmpty().mapNotNull { resource ->
                runCatching {
                    when (resource) {
                        is kotlinx.serialization.json.JsonPrimitive -> resource.contentOrNull
                        is JsonObject -> resource["name"]?.jsonPrimitive?.contentOrNull
                        else -> null
                    }
                }.getOrNull()
            }.toSet()
            val hints = o["behaviorHints"]?.let { runCatching { it.jsonObject }.getOrNull() }
            val catalogs = o["catalogs"]?.jsonArray.orEmpty().mapNotNull { element ->
                val c = runCatching { element.jsonObject }.getOrNull() ?: return@mapNotNull null
                val type = c.string("type") ?: return@mapNotNull null
                val id = c.string("id") ?: return@mapNotNull null
                StremioCatalog(
                    manifestUrl = manifestUrl,
                    addonName = name,
                    type = type,
                    id = id,
                    name = c.string("name")?.takeIf { it.isNotBlank() } ?: "$name · $type",
                    extras = c["extra"]?.let { value ->
                        runCatching {
                            value.jsonArray.mapNotNull { extra ->
                                runCatching { extra.jsonObject.string("name") }.getOrNull()
                            }.toSet()
                        }.getOrDefault(emptySet())
                    }.orEmpty(),
                )
            }
            return Manifest(
                name = name,
                version = o.string("version"),
                resources = resources,
                catalogs = catalogs,
                configurable = hints?.boolean("configurable") == true,
                configurationRequired = hints?.boolean("configurationRequired") == true,
                p2p = hints?.boolean("p2p") == true,
                adult = hints?.boolean("adult") == true,
            )
        } catch (t: Throwable) {
            Log.w(TAG, "Invalid Stremio manifest: ${t.javaClass.simpleName}: ${t.message}")
            return null
        }
    }

    /** The first page of a manifest catalogue. */
    fun catalog(catalog: StremioCatalog, extras: Map<String, String> = emptyMap()): List<StremioMeta> {
        val url = resourceUrl(catalog.manifestUrl, "catalog", catalog.type, catalog.id, extras) ?: return emptyList()
        return get(url)?.jsonObject?.get("metas")?.jsonArray.orEmpty().mapNotNull(::parseMeta)
    }

    /** Query every catalogue that explicitly advertises the standard `search` extra. */
    fun search(manifestUrl: String, query: String): List<Pair<StremioCatalog, StremioMeta>> {
        if (query.isBlank()) return emptyList()
        val manifest = manifest(manifestUrl) ?: return emptyList()
        return manifest.catalogs
            .asSequence()
            .filter { "search" in it.extras }
            .flatMap { catalog -> catalog(catalog, mapOf("search" to query.trim())).asSequence().map { catalog to it } }
            .distinctBy { (_, meta) -> "${meta.type}:${meta.id}" }
            .toList()
    }

    /** Full metadata for a movie or series. */
    fun meta(addonManifestUrl: String, type: String, id: String): StremioMeta? {
        val url = resourceUrl(addonManifestUrl, "meta", type, id) ?: return null
        val element = get(url)?.jsonObject?.get("meta") ?: return null
        return parseMeta(element)
    }

    /**
     * The streams [addonManifestUrl] offers for a title. [type] is "movie" or "series"; [id] is the
     * IMDb id — `tt1234567` for a film, `tt1234567:1:3` for series season 1 episode 3. Only entries
     * returned. The documented `infoHash` + optional `fileIdx` form is retained as a magnet hand-off.
     */
    fun streams(addonManifestUrl: String, addonName: String, type: String, id: String): List<StremioStream> {
        val url = resourceUrl(addonManifestUrl, "stream", type, id) ?: return emptyList()
        val streams = get(url)?.jsonObject?.get("streams")?.jsonArray ?: return emptyList()
        return streams.mapNotNull { element ->
            val s = element.jsonObject
            val directUrl = s["url"]?.jsonPrimitive?.contentOrNull?.takeIf(::isPlayableUrl)
            val externalUrl = s["externalUrl"]?.jsonPrimitive?.contentOrNull?.takeIf(::isExternalUrl)
            val youtubeId = s["ytId"]?.jsonPrimitive?.contentOrNull?.takeIf { it.isNotBlank() }
            val label = (s["title"] ?: s["name"])?.jsonPrimitive?.contentOrNull
                ?.replace('\n', ' ')?.trim()?.takeIf { it.isNotBlank() } ?: "Stream"
            val magnet = s.string("infoHash")?.let { hash ->
                buildMagnet(hash, s.int("fileIdx"), label, s["sources"]?.let { sourceValue ->
                    runCatching { sourceValue.jsonArray.mapNotNull { it.jsonPrimitive.contentOrNull } }
                        .getOrDefault(emptyList())
                }.orEmpty())
            }
            val requestHeaders = runCatching {
                s["behaviorHints"]?.jsonObject
                    ?.get("proxyHeaders")?.jsonObject
                    ?.get("request")?.jsonObject
                    ?.mapNotNull { (name, value) ->
                        val headerValue = value.jsonPrimitive.contentOrNull?.trim().orEmpty()
                        if (name.isBlank() || headerValue.isBlank() || name.length > 80 || headerValue.length > 4_096) null
                        else name to headerValue
                    }?.toMap().orEmpty()
            }.getOrDefault(emptyMap())
            val streamUrl = directUrl ?: externalUrl ?: youtubeId?.let { "https://www.youtube.com/watch?v=$it" }
                ?: magnet ?: return@mapNotNull null
            StremioStream(
                url = streamUrl,
                title = label,
                addonName = addonName,
                // HTTP(S) externalUrl values are attempted through OpenTV's own player too. Some
                // add-ons use that field for an ordinary HLS/DASH redirect even though the
                // protocol calls it external. Only a magnet descriptor remains non-playable: it
                // is peer-discovery metadata, not bytes a media decoder can consume.
                external = magnet != null && directUrl == null && externalUrl == null && youtubeId == null,
                p2p = magnet != null && directUrl == null && externalUrl == null && youtubeId == null,
                requestHeaders = requestHeaders,
            )
        }
    }

    /** External subtitle tracks for a movie or a specific series episode. */
    fun subtitles(addonManifestUrl: String, type: String, id: String): List<StremioSubtitle> {
        val url = resourceUrl(addonManifestUrl, "subtitles", type, id) ?: return emptyList()
        val subtitles = get(url)?.jsonObject?.get("subtitles")?.jsonArray ?: return emptyList()
        return subtitles.mapNotNull { element ->
            val s = runCatching { element.jsonObject }.getOrNull() ?: return@mapNotNull null
            val subtitleUrl = s.string("url")?.takeIf { it.startsWith("http://") || it.startsWith("https://") }
                ?: return@mapNotNull null
            val language = s.string("lang")?.ifBlank { "und" } ?: "und"
            val label = s.string("name")?.takeIf { it.isNotBlank() } ?: language
            StremioSubtitle(url = subtitleUrl, language = language, label = label)
        }
    }

    private fun parseMeta(element: JsonElement): StremioMeta? {
        val o = runCatching { element.jsonObject }.getOrNull() ?: return null
        val id = o.string("id") ?: return null
        val type = o.string("type") ?: return null
        val name = o.string("name") ?: return null
        val genres = o["genres"]?.let { value ->
            runCatching { value.jsonArray.mapNotNull { it.jsonPrimitive.contentOrNull } }.getOrDefault(emptyList())
        }.orEmpty()
        val videos = o["videos"]?.let { value ->
            runCatching {
                value.jsonArray.mapNotNull { video ->
                    val v = video.jsonObject
                    val videoId = v.string("id") ?: return@mapNotNull null
                    StremioVideo(
                        id = videoId,
                        title = v.string("title") ?: v.string("name") ?: videoId,
                        season = v.int("season"),
                        episode = v.int("episode"),
                        thumbnail = v.string("thumbnail"),
                    )
                }
            }.getOrDefault(emptyList())
        }.orEmpty()
        return StremioMeta(
            id = id,
            type = type,
            name = name,
            poster = o.string("poster"),
            background = o.string("background") ?: o.string("logo"),
            description = o.string("description"),
            releaseInfo = o.string("releaseInfo") ?: o.string("year"),
            genres = genres,
            imdbRating = o.string("imdbRating"),
            videos = videos,
        )
    }

    /**
     * Resolve a resource URL relative to the complete configured manifest URL. This preserves
     * personalised/configuration path segments while encoding IDs such as `tt123:1:2` safely.
     */
    private fun resourceUrl(
        manifestUrl: String,
        resource: String,
        type: String,
        id: String,
        extras: Map<String, String> = emptyMap(),
    ): HttpUrl? {
        val manifest = manifestUrl.trim().toHttpUrlOrNull() ?: return null
        val builder = manifest.newBuilder().query(null).fragment(null)
        if (builder.build().pathSegments.lastOrNull() == "manifest.json") {
            builder.removePathSegment(builder.build().pathSegments.lastIndex)
        }
        builder.addPathSegment(resource).addPathSegment(type)
        if (extras.isEmpty()) return builder.addPathSegment("$id.json").build()
        val encoded = extras.entries.joinToString("&") { (key, value) ->
            "${URLEncoder.encode(key, StandardCharsets.UTF_8)}=${URLEncoder.encode(value, StandardCharsets.UTF_8)}"
        }
        return builder.addPathSegment(id).addEncodedPathSegment("$encoded.json").build()
    }

    private fun JsonObject.string(key: String): String? =
        this[key]?.let { runCatching { it.jsonPrimitive.contentOrNull }.getOrNull() }

    private fun JsonObject.int(key: String): Int? =
        this[key]?.let { runCatching { it.jsonPrimitive.intOrNull }.getOrNull() }

    private fun JsonObject.boolean(key: String): Boolean? =
        this[key]?.let { runCatching { it.jsonPrimitive.contentOrNull?.toBooleanStrictOrNull() }.getOrNull() }

    private fun isPlayableUrl(value: String): Boolean =
        value.startsWith("http://", true) || value.startsWith("https://", true) ||
            value.startsWith("rtmp://", true) || value.startsWith("rtsp://", true) ||
            value.startsWith("ftp://", true) || value.startsWith("ftps://", true)

    private fun isExternalUrl(value: String): Boolean =
        value.startsWith("http://", true) || value.startsWith("https://", true)

    private fun buildMagnet(hash: String, fileIdx: Int?, label: String, sources: List<String>): String? {
        val clean = hash.trim()
        if (!clean.matches(Regex("(?i)([a-f0-9]{40}|[a-z2-7]{32})"))) return null
        val encode: (String) -> String = { URLEncoder.encode(it, StandardCharsets.UTF_8) }
        return buildString {
            append("magnet:?xt=urn:btih:").append(clean)
            append("&dn=").append(encode(label))
            if (fileIdx != null && fileIdx >= 0) append("&so=").append(fileIdx)
            sources.asSequence().filter { it.startsWith("tracker:") }.take(12).forEach { source ->
                append("&tr=").append(encode(source.removePrefix("tracker:")))
            }
        }
    }

    private fun get(url: HttpUrl): JsonElement? {
        val request = Request.Builder().url(url).header("User-Agent", "OpenTV").build()
        return runCatching {
            http.newCall(request).apply { timeout().timeout(12, TimeUnit.SECONDS) }.execute().use { response ->
                if (!response.isSuccessful) {
                    Log.w(TAG, "Stremio request returned HTTP ${response.code} for ${url.host}")
                    return null
                }
                val body = response.body?.string() ?: return null
                json.parseToJsonElement(body)
            }
        }.onFailure {
            // Android TV logcat occasionally drops Throwable continuation lines; keep the useful
            // class/message on the first line so a failed manifest can actually be diagnosed.
            Log.w(TAG, "Stremio request failed for ${url.host}: ${it.javaClass.simpleName}: ${it.message}")
        }.getOrNull()
    }

    private companion object {
        const val TAG = "StremioClient"
    }
}
