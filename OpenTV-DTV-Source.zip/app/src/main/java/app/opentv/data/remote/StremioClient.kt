/*
 * This file is part of OpenTV.
 * Copyright (C) 2026 The OpenTV Contributors
 * Licensed under the GNU General Public License v3.0 or later.
 */
package app.opentv.data.remote

import android.util.Log
import app.opentv.data.model.StremioCatalog
import app.opentv.data.model.StremioMeta
import app.opentv.data.model.StremioSubtitle
import app.opentv.data.model.StremioStream
import app.opentv.data.model.StremioVideo
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.intOrNull
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import okhttp3.HttpUrl
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit

/**
 * A thin, read-only client for the open Stremio add-on protocol — the same protocol Stremio and
 * many Kodi add-ons speak. OpenTV ships with no add-ons and hosts no content; this only talks to
 * manifest URLs the user has pasted in themselves.
 *
 * ## What it does
 * - [fetchManifest] fetches an add-on's `manifest.json` and returns its display name if it looks
 *   like a real add-on (has an id + name), so the settings screen can validate a pasted URL.
 * - [streams] asks an add-on for the streams it offers for a title and returns only the ones with a
 *   direct playable URL. Debrid-backed add-ons resolve a title to such a URL internally (using the
 *   debrid key baked into the user's personalised manifest URL), so OpenTV never handles a debrid
 *   key and never touches a torrent — it just plays the URL the add-on hands back.
 *
 * ## Blocking on purpose
 * Methods block on the calling thread; callers already run them inside `withContext(Dispatchers.IO)`,
 * matching [TmdbClient].
 */
class StremioClient(
    private val http: OkHttpClient,
    private val json: Json = Json { ignoreUnknownKeys = true; isLenient = true },
) {

    data class Manifest(
        val name: String,
        val resources: Set<String>,
        val catalogs: List<StremioCatalog>,
    )

    /**
     * Fetch and lightly validate an add-on manifest. Returns the add-on's display name, or null if
     * the URL doesn't resolve to something that looks like a Stremio manifest (id + name present).
     */
    fun fetchManifest(manifestUrl: String): String? = manifest(manifestUrl)?.name

    /** Fetch the capabilities and catalogue rows advertised by an add-on. */
    fun manifest(manifestUrl: String): Manifest? {
        try {
            val url = manifestUrl.trim().toHttpUrlOrNull() ?: return null
            val o = get(url)?.jsonObject ?: return null
            val name = o["name"]?.jsonPrimitive?.contentOrNull?.takeIf { it.isNotBlank() } ?: return null
            val hasId = o["id"]?.jsonPrimitive?.contentOrNull?.isNotBlank() == true
            if (!hasId) return null
            val resources = o["resources"]?.jsonArray.orEmpty().mapNotNull { resource ->
                runCatching {
                    when (resource) {
                        is kotlinx.serialization.json.JsonPrimitive -> resource.contentOrNull
                        is JsonObject -> resource["name"]?.jsonPrimitive?.contentOrNull
                        else -> null
                    }
                }.getOrNull()
            }.toSet()
            val catalogs = o["catalogs"]?.jsonArray.orEmpty().mapNotNull { element ->
                val c = runCatching { element.jsonObject }.getOrNull() ?: return@mapNotNull null
                val type = c.string("type") ?: return@mapNotNull null
                val id = c.string("id") ?: return@mapNotNull null
                StremioCatalog(
                    manifestUrl = manifestUrl,
                    addonName = name,
                    type = type,
                    id = id,
                    name = c.string("name")?.takeIf { it.isNotBlank() } ?: "$name · $type",
                )
            }
            return Manifest(name = name, resources = resources, catalogs = catalogs)
        } catch (t: Throwable) {
            Log.w(TAG, "Invalid Stremio manifest: ${t.javaClass.simpleName}: ${t.message}")
            return null
        }
    }

    /** The first page of a manifest catalogue. */
    fun catalog(catalog: StremioCatalog): List<StremioMeta> {
        val url = resourceUrl(catalog.manifestUrl, "catalog", catalog.type, catalog.id) ?: return emptyList()
        return get(url)?.jsonObject?.get("metas")?.jsonArray.orEmpty().mapNotNull(::parseMeta)
    }

    /** Full metadata for a movie or series. */
    fun meta(addonManifestUrl: String, type: String, id: String): StremioMeta? {
        val url = resourceUrl(addonManifestUrl, "meta", type, id) ?: return null
        val element = get(url)?.jsonObject?.get("meta") ?: return null
        return parseMeta(element)
    }

    /**
     * The streams [addonManifestUrl] offers for a title. [type] is "movie" or "series"; [id] is the
     * IMDb id — `tt1234567` for a film, `tt1234567:1:3` for series season 1 episode 3. Only entries
     * with a direct `url` are returned (see the class note on why torrents are skipped).
     */
    fun streams(addonManifestUrl: String, addonName: String, type: String, id: String): List<StremioStream> {
        val url = resourceUrl(addonManifestUrl, "stream", type, id) ?: return emptyList()
        val streams = get(url)?.jsonObject?.get("streams")?.jsonArray ?: return emptyList()
        return streams.mapNotNull { element ->
            val s = element.jsonObject
            val directUrl = s["url"]?.jsonPrimitive?.contentOrNull?.takeIf { it.isNotBlank() }
            val externalUrl = s["externalUrl"]?.jsonPrimitive?.contentOrNull?.takeIf { it.isNotBlank() }
            val youtubeId = s["ytId"]?.jsonPrimitive?.contentOrNull?.takeIf { it.isNotBlank() }
            val streamUrl = directUrl ?: externalUrl ?: youtubeId?.let { "https://www.youtube.com/watch?v=$it" }
                ?: return@mapNotNull null // infoHash-only (raw torrent) — skipped on purpose
            val label = (s["title"] ?: s["name"])?.jsonPrimitive?.contentOrNull
                ?.replace('\n', ' ')?.trim()?.takeIf { it.isNotBlank() } ?: "Stream"
            StremioStream(
                url = streamUrl,
                title = label,
                addonName = addonName,
                external = directUrl == null,
            )
        }
    }

    /** External subtitle tracks for a movie or a specific series episode. */
    fun subtitles(addonManifestUrl: String, type: String, id: String): List<StremioSubtitle> {
        val url = resourceUrl(addonManifestUrl, "subtitles", type, id) ?: return emptyList()
        val subtitles = get(url)?.jsonObject?.get("subtitles")?.jsonArray ?: return emptyList()
        return subtitles.mapNotNull { element ->
            val s = runCatching { element.jsonObject }.getOrNull() ?: return@mapNotNull null
            val subtitleUrl = s.string("url")?.takeIf { it.startsWith("http://") || it.startsWith("https://") }
                ?: return@mapNotNull null
            val language = s.string("lang")?.ifBlank { "und" } ?: "und"
            val label = s.string("name")?.takeIf { it.isNotBlank() } ?: language
            StremioSubtitle(url = subtitleUrl, language = language, label = label)
        }
    }

    private fun parseMeta(element: JsonElement): StremioMeta? {
        val o = runCatching { element.jsonObject }.getOrNull() ?: return null
        val id = o.string("id") ?: return null
        val type = o.string("type") ?: return null
        val name = o.string("name") ?: return null
        val genres = o["genres"]?.let { value ->
            runCatching { value.jsonArray.mapNotNull { it.jsonPrimitive.contentOrNull } }.getOrDefault(emptyList())
        }.orEmpty()
        val videos = o["videos"]?.let { value ->
            runCatching {
                value.jsonArray.mapNotNull { video ->
                    val v = video.jsonObject
                    val videoId = v.string("id") ?: return@mapNotNull null
                    StremioVideo(
                        id = videoId,
                        title = v.string("title") ?: v.string("name") ?: videoId,
                        season = v.int("season"),
                        episode = v.int("episode"),
                        thumbnail = v.string("thumbnail"),
                    )
                }
            }.getOrDefault(emptyList())
        }.orEmpty()
        return StremioMeta(
            id = id,
            type = type,
            name = name,
            poster = o.string("poster"),
            background = o.string("background") ?: o.string("logo"),
            description = o.string("description"),
            releaseInfo = o.string("releaseInfo") ?: o.string("year"),
            genres = genres,
            imdbRating = o.string("imdbRating"),
            videos = videos,
        )
    }

    /**
     * Resolve a resource URL relative to the complete configured manifest URL. This preserves
     * personalised/configuration path segments while encoding IDs such as `tt123:1:2` safely.
     */
    private fun resourceUrl(manifestUrl: String, resource: String, type: String, id: String): HttpUrl? {
        val manifest = manifestUrl.trim().toHttpUrlOrNull() ?: return null
        val builder = manifest.newBuilder().query(null).fragment(null)
        if (builder.build().pathSegments.lastOrNull() == "manifest.json") {
            builder.removePathSegment(builder.build().pathSegments.lastIndex)
        }
        return builder
            .addPathSegment(resource)
            .addPathSegment(type)
            .addPathSegment("$id.json")
            .build()
    }

    private fun JsonObject.string(key: String): String? =
        this[key]?.let { runCatching { it.jsonPrimitive.contentOrNull }.getOrNull() }

    private fun JsonObject.int(key: String): Int? =
        this[key]?.let { runCatching { it.jsonPrimitive.intOrNull }.getOrNull() }

    private fun get(url: HttpUrl): JsonElement? {
        val request = Request.Builder().url(url).header("User-Agent", "OpenTV").build()
        return runCatching {
            http.newCall(request).apply { timeout().timeout(25, TimeUnit.SECONDS) }.execute().use { response ->
                if (!response.isSuccessful) {
                    Log.w(TAG, "Stremio request returned HTTP ${response.code} for ${url.host}")
                    return null
                }
                val body = response.body?.string() ?: return null
                json.parseToJsonElement(body)
            }
        }.onFailure {
            // Android TV logcat occasionally drops Throwable continuation lines; keep the useful
            // class/message on the first line so a failed manifest can actually be diagnosed.
            Log.w(TAG, "Stremio request failed for ${url.host}: ${it.javaClass.simpleName}: ${it.message}")
        }.getOrNull()
    }

    private companion object {
        const val TAG = "StremioClient"
    }
}
