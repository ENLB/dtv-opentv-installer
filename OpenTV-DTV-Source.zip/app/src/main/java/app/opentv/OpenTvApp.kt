/*
 * This file is part of OpenTV.
 * Copyright (C) 2026 The OpenTV Contributors
 * Licensed under the GNU General Public License v3.0 or later.
 */
package app.opentv

import android.app.Application
import android.content.Context
import app.opentv.core.LocaleUtils
import app.opentv.core.ServiceLocator
import app.opentv.data.model.Source
import app.opentv.data.model.SourceKind
import app.opentv.data.model.StremioAddon
import app.opentv.data.parser.M3uParser
import app.opentv.data.repo.CatalogRepository
import app.opentv.data.work.SyncWorker
import app.opentv.sync.LocalDtvContentServer
import coil.ImageLoader
import coil.ImageLoaderFactory
import coil.disk.DiskCache
import coil.memory.MemoryCache
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay

class OpenTvApp : Application(), ImageLoaderFactory {
    private val appScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    /**
     * The app-wide Coil loader, tuned for a poster-and-logo heavy UI on a low-end TV box. The
     * default loader keeps a small memory cache and no disk cache, so scrolling back through a
     * shelf — or reopening Movies — re-downloads and re-decodes every image. Here:
     *  - a generous memory cache and a 256 MB disk cache mean art you've already seen paints from
     *    cache, instantly, instead of hitting the network;
     *  - no crossfade — an immediate swap reads as snappier on a d-pad grid than a fade, and skips
     *    a frame of blending per image;
     *  - RGB_565 for opaque art (posters/backdrops) halves the memory per bitmap, so more fits in
     *    cache; Coil keeps ARGB_8888 for anything with transparency, so channel logos are untouched.
     */
    override fun newImageLoader(): ImageLoader =
        ImageLoader.Builder(this)
            .memoryCache {
                MemoryCache.Builder(this)
                    // Keep enough headroom for the guide, ExoPlayer and add-on shelves. The old
                    // 25% image cache was too aggressive beside a 10k-channel/80k-programme DB on
                    // the Streamer and amplified Android's memory-pressure exits.
                    .maxSizePercent(0.12)
                    .build()
            }
            .diskCache {
                DiskCache.Builder()
                    .directory(cacheDir.resolve("image_cache"))
                    .maxSizeBytes(256L * 1024 * 1024)
                    .build()
            }
            .crossfade(false)
            .allowRgb565(true)
            .build()

    // So notifications and any app-context resources use the chosen language too, not just the UI.
    override fun attachBaseContext(base: Context) {
        super.attachBaseContext(LocaleUtils.wrap(base))
    }

    override fun onCreate() {
        super.onCreate()
        val graph = ServiceLocator.get(this)
        if (BuildConfig.APPLICATION_ID.endsWith(".stremiolab")) {
            LocalDtvContentServer.start(this)
        }
        SyncWorker.schedule(this)

        // This D TV build is deliberately self-contained. Its playlist and guide are bundled in
        // the APK and served on loopback, so fresh installs need neither a public
        // repository nor the owner's PC. The v2 migration replaces the former public GitHub URL
        // without clearing the imported catalogue, favourites or other user state.
        if (BuildConfig.APPLICATION_ID.endsWith(".stremiolab")) {
            appScope.launch {
                val prefs = getSharedPreferences("opentv", MODE_PRIVATE)
                val alreadyHadBundledFeed = prefs.getBoolean("dtv_private_content_seed_v2", false)
                if (!prefs.getBoolean("dtv_on_demand_tabs_v1", false)) {
                    graph.settings.setMoviesEnabled(true)
                    graph.settings.setSeriesEnabled(true)
                    prefs.edit().putBoolean("dtv_on_demand_tabs_v1", true).apply()
                }
                if (!prefs.getBoolean("dtv_private_content_seed_v2", false)) {
                    val sources = graph.sourceRepository.enabled()
                    val existing = sources.firstOrNull {
                        it.name == "D TV - Interdimensional Cable" || it.name == "D TV — OpenTV"
                    }
                    val source = when {
                        existing != null && (existing.url != LocalDtvContentServer.PLAYLIST_URL || existing.name != "D TV — OpenTV") -> {
                            existing.copy(
                                name = "D TV — OpenTV",
                                url = LocalDtvContentServer.PLAYLIST_URL,
                                epgUrl = LocalDtvContentServer.GUIDE_URL,
                                lastCatalogSyncMillis = 0,
                            )
                        }
                        existing == null -> {
                            Source(
                                name = "D TV — OpenTV",
                                kind = SourceKind.M3U,
                                url = LocalDtvContentServer.PLAYLIST_URL,
                                epgUrl = LocalDtvContentServer.GUIDE_URL,
                            )
                        }
                        else -> existing
                    }
                    val sourceId = graph.sourceRepository.save(source)
                    val saved = source.copy(id = sourceId)
                    // Fresh installs must not depend on WorkManager, internet-state detection or
                    // a loopback HTTP race. Import the APK asset directly and mark the migration
                    // complete only after Room contains the catalogue, so a failure retries next
                    // launch instead of permanently leaving an empty app.
                    val imported = assets.open("dtv/dtv.m3u8").use { input ->
                        graph.catalogRepository.syncBundledM3u(
                            saved,
                            input,
                            System.currentTimeMillis(),
                        )
                    }
                    if (imported is CatalogRepository.SyncResult.Success) {
                        prefs.edit()
                            .putBoolean("dtv_private_content_seed_v2", true)
                            .putBoolean("dtv_curated_favourites_v8", true)
                            .putBoolean("dtv_organised_bundle_v19", true)
                            .apply()
                    }
                }
                // 0.12.5 expands the virtual folders and corrects overly literal genre/sport
                // matching. Refresh an existing D TV catalogue once, after the first screen has
                // had time to draw. Fresh installs are already importing this exact asset above.
                if (!prefs.getBoolean("dtv_folder_catalog_v12", false)) {
                    if (alreadyHadBundledFeed) {
                        delay(20_000)
                        graph.sourceRepository.enabled()
                            .firstOrNull { it.name == "D TV — OpenTV" || it.name == "D TV - Interdimensional Cable" }
                            ?.let {
                                graph.sourceRepository.save(it.copy(lastCatalogSyncMillis = 0))
                                SyncWorker.refreshNow(this@OpenTvApp)
                            }
                    }
                    prefs.edit().putBoolean("dtv_folder_catalog_v12", true).apply()
                }
                // 0.13.0 replaces the small hard-coded shelf list with the generated universal
                // classification catalogue. Re-import channel metadata once while preserving the
                // DAO's user-state fields (personal favourites, names, hidden state and ordering).
                if (!prefs.getBoolean("dtv_universal_library_v13", false)) {
                    if (alreadyHadBundledFeed) {
                        delay(20_000)
                        graph.sourceRepository.enabled()
                            .firstOrNull { it.name == "D TV — OpenTV" || it.name == "D TV - Interdimensional Cable" }
                            ?.let {
                                graph.sourceRepository.save(it.copy(lastCatalogSyncMillis = 0))
                                SyncWorker.refreshNow(this@OpenTvApp)
                            }
                    }
                    prefs.edit().putBoolean("dtv_universal_library_v13", true).apply()
                }
                // 0.13.7 expands the bundled public FAST/FTA library. Refresh once after the UI is
                // interactive so existing installs receive the new channels and folder metadata
                // without a destructive reset or a cold-start ANR. Catalogue replacement preserves
                // user favourites, hidden channels and custom names in ChannelDao.
                if (!prefs.getBoolean("dtv_public_library_v16", false)) {
                    if (alreadyHadBundledFeed) {
                        delay(45_000)
                        graph.sourceRepository.enabled()
                            .firstOrNull { it.name == "D TV — OpenTV" || it.name == "D TV - Interdimensional Cable" }
                            ?.let {
                                graph.sourceRepository.save(it.copy(lastCatalogSyncMillis = 0))
                                SyncWorker.refreshNow(this@OpenTvApp)
                            }
                    }
                    prefs.edit()
                        .putBoolean("dtv_public_library_v15", true)
                        .putBoolean("dtv_public_library_v16", true)
                        .apply()
                }
                // 0.13.10 is the first correctly-published self-contained release after the plain
                // upstream APK was accidentally placed behind the Downloader code. Existing D TV
                // installs get one direct, non-destructive catalogue import from the APK itself;
                // this preserves favourites/hidden/custom state and avoids the loopback/WorkManager
                // race that made a fresh phone install look empty.
                if (!prefs.getBoolean("dtv_organised_bundle_v19", false)) {
                    if (alreadyHadBundledFeed) delay(15_000)
                    val source = graph.sourceRepository.enabled().firstOrNull {
                        it.name == "D TV — OpenTV" || it.name == "D TV - Interdimensional Cable"
                    }
                    if (source != null) {
                        val imported = assets.open("dtv/dtv.m3u8").use { input ->
                            graph.catalogRepository.syncBundledM3u(
                                source,
                                input,
                                System.currentTimeMillis(),
                            )
                        }
                        if (imported is CatalogRepository.SyncResult.Success) {
                            prefs.edit().putBoolean("dtv_organised_bundle_v19", true).apply()
                        }
                    }
                }
                // Import the matching expanded guide once the catalogue has settled. The parser
                // streams batches into Room; failure leaves the previous guide intact and retries.
                // Import it directly after the app has been idle long enough for remote input and
                // first playback to settle. The parser streams batches into Room, so it does not
                // inflate the complete XML in memory; failure leaves the prior guide intact and
                // retries next launch.
                if (!prefs.getBoolean("dtv_bundled_guide_v19", false)) {
                    delay(45_000)
                    val source = graph.sourceRepository.enabled().firstOrNull {
                        it.name == "D TV — OpenTV" || it.name == "D TV - Interdimensional Cable"
                    }
                    if (source != null) {
                        val summary = runCatching {
                            assets.open("dtv/guide.xmltvz").use { input ->
                                graph.epgRepository.syncBundledProviderGuide(
                                    source.id,
                                    input,
                                    System.currentTimeMillis(),
                                )
                            }
                        }.getOrNull()
                        if (summary != null && summary.feedsSucceeded > 0 && summary.programmesWritten > 0) {
                            prefs.edit()
                                .putBoolean("dtv_bundled_guide_v14", true)
                                .putBoolean("dtv_bundled_guide_v17", true)
                                .putBoolean("dtv_bundled_guide_v19", true)
                                .apply()
                        }
                    }
                }
                // The descriptive phrase used by older builds was never meant to be the source
                // title. Rename it in place without changing credentials, channel state or ids.
                graph.sourceRepository.enabled()
                    .firstOrNull { it.name == "D TV - Interdimensional Cable" }
                    ?.let { graph.sourceRepository.save(it.copy(name = "D TV — OpenTV")) }

                // Seed the useful, currently reachable catalogue/metadata/direct-web/trailer and
                // subtitle services the owner selected. This is add-only: anything already saved
                // is preserved, duplicate URLs collapse, and a service is stored only after its
                // live manifest validates. No account or credential is created or bundled.
                if (!prefs.getBoolean("dtv_useful_addons_v11", false)) {
                    USEFUL_ADDONS.chunked(4).forEach { batch ->
                        coroutineScope {
                            batch.map { manifestUrl ->
                                async(Dispatchers.IO) {
                                    manifestUrl to runCatching { graph.stremioClient.manifest(manifestUrl) }.getOrNull()
                                }
                            }.awaitAll()
                        }.forEach { (manifestUrl, manifest) ->
                            manifest?.let {
                                graph.settings.addStremioAddon(
                                    StremioAddon(
                                        manifestUrl = manifestUrl,
                                        name = it.name,
                                        version = it.version,
                                        resources = it.resources,
                                        configurable = it.configurable || it.configurationRequired,
                                        p2p = it.p2p,
                                        adult = it.adult,
                                    ),
                                )
                            }
                        }
                    }
                    prefs.edit().putBoolean("dtv_useful_addons_v11", true).apply()
                }
                // Backfill capability/version metadata for add-ons saved by earlier builds. The
                // manifest URL and enabled state are preserved; failures leave the old entry intact.
                if (!prefs.getBoolean("dtv_addon_metadata_v13", false)) {
                    graph.settings.stremioAddons.value.chunked(4).forEach { batch ->
                        coroutineScope {
                            batch.map { addon ->
                                async(Dispatchers.IO) {
                                    addon to runCatching { graph.stremioClient.manifest(addon.manifestUrl) }.getOrNull()
                                }
                            }.awaitAll()
                        }.forEach { (addon, manifest) ->
                            manifest?.let {
                                graph.settings.updateStremioAddon(
                                    addon.copy(
                                        name = it.name,
                                        version = it.version,
                                        resources = it.resources,
                                        configurable = it.configurable || it.configurationRequired,
                                        p2p = it.p2p,
                                        adult = it.adult,
                                    ),
                                )
                            }
                        }
                    }
                    prefs.edit().putBoolean("dtv_addon_metadata_v13", true).apply()
                }
            }
        }

        // Upgrade existing household installs to the curated favourites shipped in the bundled
        // playlist. New installs receive the same flags during M3U import; this one-time pass is
        // for devices whose rows pre-date those flags. Existing favourites are only added to,
        // never cleared. The catalogue and guide are not re-imported here: doing that duplicated
        // the normal source refresh and could briefly starve the TV UI on first launch.
        if (BuildConfig.APPLICATION_ID.endsWith(".stremiolab")) {
            appScope.launch {
                val prefs = getSharedPreferences("opentv", MODE_PRIVATE)
                if (!prefs.getBoolean("dtv_curated_favourites_v8", false)) {
                    // Give Compose time to draw before parsing the bundled favourites. This pass
                    // only repairs favourite flags on older catalogues; source refresh owns the
                    // expensive channel and guide imports.
                    kotlinx.coroutines.delay(15_000)
                    val source = graph.sourceRepository.enabled()
                        .firstOrNull { it.name == "D TV — OpenTV" || it.name == "D TV - Interdimensional Cable" }
                    if (source != null) {
                        val curated = assets.open("dtv/dtv.m3u8").use {
                            M3uParser.parse(it, source.id).channels.filter { channel -> channel.favourite }
                        }
                        graph.catalogRepository.markChannelFavouritesByUrl(curated.map { it.streamUrl })
                        prefs.edit().putBoolean("dtv_curated_favourites_v8", true).apply()
                    }
                }
            }
        }

        // When the normaliser has moved on since the catalogue was last processed, re-clean
        // the stored channels and re-run the guide matcher — locally, no re-download. This
        // is why a name-cleanup fix shows up on the next launch rather than the next 6-hour
        // sync, and it costs nothing when the version has not changed.
        // Cold-start reconciliation: a recording still marked "in progress" at process start is an
        // orphan from a killed capture. Done here, once per process — NOT when the Recordings screen
        // opens — so checking on a recording you just started never marks it interrupted.
        appScope.launch { runCatching { graph.recordingRepository.failInterrupted() } }

        // Re-arm scheduled recordings on every launch, for the same reason as the reminders below:
        // a force-stop or app update drops their exact alarms and only a reboot is covered by the
        // boot receiver. Re-setting the same alarm is idempotent, so this quietly keeps bookings alive.
        appScope.launch { runCatching { graph.recordingEngine.rearmScheduled() } }

        // Re-arm programme reminders on every launch. Alarms are lost on a force-stop or app
        // update (not just a reboot, which the boot receiver already covers), and re-setting an
        // exact alarm for the same reminder is idempotent — so this quietly keeps bells alive.
        appScope.launch {
            runCatching {
                val now = System.currentTimeMillis()
                graph.reminderRepository.deleteEndedBefore(now)
                graph.reminderRepository.upcoming(now).forEach {
                    app.opentv.reminders.ReminderScheduler.set(this@OpenTvApp, it.id, it.startUtcMillis)
                }
            }
        }

        // Free, server-less "cloud" sync through the user's own NAS, if they've opted in. Writes
        // this device's bundle to the shared folder and merges in every other device's — favourites,
        // watch history and NAS recordings. Fire-and-forget and fully guarded: a blank or unreachable
        // NAS returns a result rather than throwing, so a bad launch never costs the user anything.
        if (graph.settings.nasAutoSync.value) {
            appScope.launch { runCatching { app.opentv.sync.NasSync(graph).sync() } }
        }

        appScope.launch {
            // Keep database migrations and guide reconciliation away from the first interactive
            // frames. The D TV variant's WorkManager import already owns guide refreshes; running
            // syncAll here too caused two full parses to compete on fresh installs.
            delay(30_000)
            val prefs = getSharedPreferences("opentv", MODE_PRIVATE)
            val seen = prefs.getInt("normalizer_version", 0)
            if (seen < CatalogRepository.NORMALIZER_VERSION) {
                graph.catalogRepository.renormalizeAll()
                prefs.edit().putInt("normalizer_version", CatalogRepository.NORMALIZER_VERSION).apply()
            }
            // Runs on every launch. It is cheap when nothing is stale (feeds within their
            // refresh window are skipped), but it is what makes the free regional guide turn
            // itself on and download the first time — without waiting for the user to find
            // the refresh button. ensureFeeds + auto-enable-by-region + matcher all live here.
            if (!BuildConfig.APPLICATION_ID.endsWith(".stremiolab")) {
                graph.epgRepository.syncAll(System.currentTimeMillis(), force = false)
            }
        }
    }

    private companion object {
        val USEFUL_ADDONS = listOf(
            "https://v3-cinemeta.strem.io/manifest.json",
            "https://aiometadata.elfhosted.com/stremio/477d504d-5cb8-455d-8fc5-ab80ed684057/manifest.json",
            "https://87d6a6ef6b58-webstreamrmbg.baby-beamup.club/%7B%22multi%22%3A%22on%22%2C%22mediaFlowProxyUrl%22%3A%22%22%2C%22mediaFlowProxyPassword%22%3A%22%22%7D/manifest.json",
            "https://streailer.elfhosted.com/%7B%22language%22%3A%22en-US%22%2C%22externalLink%22%3Afalse%2C%22showRecap%22%3Atrue%2C%22onlyRecaps%22%3Afalse%7D/manifest.json",
            "https://subsense.nepiraw.com/hd7uwglr-%7B%22languages%22%3A%5B%22en%22%5D%2C%22maxSubtitles%22%3A10%7D/manifest.json",
            "https://opensubtitlesv3-pro.dexter21767.com/eyJsYW5ncyI6WyJlbmdsaXNoIl0sInNvdXJjZSI6ImFsbCIsImFpVHJhbnNsYXRlZCI6dHJ1ZSwiYXV0b0FkanVzdG1lbnQiOnRydWV9/manifest.json",
            "https://opensubtitles-v3.strem.io/manifest.json",
            "https://watchhub.strem.io/manifest.json",
        )
    }
}
