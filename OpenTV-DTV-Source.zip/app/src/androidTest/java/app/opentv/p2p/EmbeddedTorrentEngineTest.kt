package app.opentv.p2p

import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.media3.datasource.DataSpec
import android.net.Uri
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith

/** End-to-end Android smoke test using WebTorrent's Creative Commons Big Buck Bunny fixture. */
@RunWith(AndroidJUnit4::class)
class EmbeddedTorrentEngineTest {
    @Test
    fun obtainsMetadataAndCreatesLocalPlaybackSource() = runBlocking {
        val magnet = "magnet:?xt=urn:btih:dd8255ecdc7ca55fb0bbf81323d87062db1f6d1c" +
            "&dn=Big+Buck+Bunny" +
            "&tr=udp%3A%2F%2Ftracker.opentrackr.org%3A1337" +
            "&ws=https%3A%2F%2Fwebtorrent.io%2Ftorrents%2F" +
            "&xs=https%3A%2F%2Fwebtorrent.io%2Ftorrents%2Fbig-buck-bunny.torrent"
        val result = withTimeout(120_000) {
            EmbeddedTorrentEngine.get(ApplicationProvider.getApplicationContext()).prepare(magnet)
        }
        assertTrue(result.first.startsWith("optvp2p://"))
        assertTrue(result.second.substringAfterLast('.').lowercase() in setOf("mp4", "mkv", "webm"))
        val source = TorrentDataSource(EmbeddedTorrentEngine.get(ApplicationProvider.getApplicationContext()))
        source.open(DataSpec(Uri.parse(result.first)))
        val firstBytes = ByteArray(1024)
        assertTrue("Expected the embedded engine to download playable bytes", source.read(firstBytes, 0, firstBytes.size) > 0)
        source.close()
    }
}
