package app.opentv.syncbridge

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.util.Log
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

class BridgeReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        schedule(context)
        val pending = goAsync()
        thread(name = "opentv-sync-bridge") {
            try {
                val connection = URL("http://192.168.0.84:18742/addons").openConnection() as HttpURLConnection
                connection.connectTimeout = 3_000
                connection.readTimeout = 5_000
                val body = connection.inputStream.bufferedReader().use { it.readText() }
                connection.disconnect()
                context.sendBroadcast(
                    Intent("app.opentv.stremiolab.APPLY_ADDONS")
                        .setComponent(ComponentName("app.opentv.stremiolab", "app.opentv.sync.PortableAddonReceiver"))
                        .putExtra("payload", body),
                )
                Log.i("OpenTvSyncBridge", "Delivered D TV add-on configuration")
            } catch (error: Exception) {
                Log.w("OpenTvSyncBridge", "Could not deliver D TV add-on configuration", error)
            } finally {
                pending.finish()
            }
        }
    }

    private fun schedule(context: Context) {
        val alarm = context.getSystemService(AlarmManager::class.java)
        val intent = Intent("app.opentv.syncbridge.RUN")
            .setComponent(ComponentName(context, BridgeReceiver::class.java))
        val pending = PendingIntent.getBroadcast(
            context,
            0,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        alarm.setInexactRepeating(
            AlarmManager.ELAPSED_REALTIME_WAKEUP,
            android.os.SystemClock.elapsedRealtime() + 15 * 60_000L,
            15 * 60_000L,
            pending,
        )
    }
}
