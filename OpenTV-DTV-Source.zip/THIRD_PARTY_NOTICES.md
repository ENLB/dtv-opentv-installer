# Third-party notices

OpenTV includes **FrostWire jlibtorrent** 2.0.15.3 for embedded, on-device BitTorrent
transport. FrostWire jlibtorrent is Copyright (c) 2014 FrostWire.com and contributors and is
distributed under the MIT License. Its source and licence are available at:

https://github.com/frostwire/frostwire-jlibtorrent

The complete MIT licence text is included in the upstream project linked above. OpenTV does not
include Tribler and does not claim Tribler anonymity or its community/search functions.
